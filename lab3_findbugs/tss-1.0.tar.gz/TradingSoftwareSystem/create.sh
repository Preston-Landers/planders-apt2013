java -cp ./lib/sqlitejdbc-v056.jar:./lib/ta-lib-0.4.0.jar:./lib/javacsv.jar:. SymbolsDatabase create
