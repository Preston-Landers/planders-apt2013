
function addChartData(data) {
data.addRows([
 [new Date(2010,7,2), 39.09, undefined, undefined, undefined ],
 [new Date(2010,7,3), 39.22, undefined, undefined, undefined ],
 [new Date(2010,7,4), 39.44, undefined, undefined, undefined ],
 [new Date(2010,7,5), 39.55, undefined, undefined, undefined ],
 [new Date(2010,7,6), 39.51, undefined, undefined, undefined ],
 [new Date(2010,7,9), 39.75, undefined, undefined, undefined ],
 [new Date(2010,7,10), 39.68, undefined, undefined, undefined ],
 [new Date(2010,7,11), 38.69, undefined, undefined, undefined ],
 [new Date(2010,7,12), 38.53, undefined, undefined, undefined ],
 [new Date(2010,7,13), 38.61, undefined, undefined, undefined ],
 [new Date(2010,7,16), 38.64, undefined, undefined, undefined ],
 [new Date(2010,7,17), 39.11, undefined, undefined, undefined ],
 [new Date(2010,7,18), 39.03, undefined, undefined, undefined ],
 [new Date(2010,7,19), 38.49, undefined, undefined, undefined ],
 [new Date(2010,7,20), 38.46, undefined, undefined, undefined ],
 [new Date(2010,7,23), 38.74, undefined, undefined, undefined ],
 [new Date(2010,7,24), 38.76, undefined, undefined, undefined ],
 [new Date(2010,7,25), 38.54, undefined, undefined, undefined ],
 [new Date(2010,7,26), 38.49, undefined, undefined, undefined ],
 [new Date(2010,7,27), 39.23, undefined, undefined, undefined ],
 [new Date(2010,7,30), 38.8, undefined, undefined, undefined ],
 [new Date(2010,7,31), 39.03, undefined, undefined, undefined ],
 [new Date(2010,8,1), 39.8, undefined, undefined, undefined ]
 ]); }