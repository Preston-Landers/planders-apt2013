
function addChartData(data) {
data.addRows([
 [new Date(2010,7,2), 115.54, undefined, undefined, undefined ],
 [new Date(2010,7,3), 115.99, undefined, undefined, undefined ],
 [new Date(2010,7,4), 116.72, undefined, undefined, undefined ],
 [new Date(2010,7,5), 116.98, undefined, undefined, undefined ],
 [new Date(2010,7,6), 117.84, undefined, undefined, undefined ],
 [new Date(2010,7,9), 117.4, undefined, undefined, undefined ],
 [new Date(2010,7,10), 117.73, undefined, undefined, undefined ],
 [new Date(2010,7,11), 117.34, undefined, undefined, undefined ],
 [new Date(2010,7,12), 118.77, undefined, undefined, undefined ],
 [new Date(2010,7,13), 118.74, undefined, undefined, undefined ],
 [new Date(2010,7,16), 119.73, undefined, undefined, undefined ],
 [new Date(2010,7,17), 119.75, undefined, undefined, undefined ],
 [new Date(2010,7,18), 120.22, undefined, undefined, undefined ],
 [new Date(2010,7,19), 120.39, undefined, undefined, undefined ],
 [new Date(2010,7,20), 119.97, undefined, undefined, undefined ],
 [new Date(2010,7,23), 119.78, undefined, undefined, undefined ],
 [new Date(2010,7,24), 120.36, undefined, undefined, undefined ],
 [new Date(2010,7,25), 121.36, undefined, undefined, undefined ],
 [new Date(2010,7,26), 120.96, undefined, undefined, undefined ],
 [new Date(2010,7,27), 121.01, undefined, undefined, undefined ],
 [new Date(2010,7,30), 120.91, undefined, undefined, undefined ],
 [new Date(2010,7,31), 122.08, undefined, undefined, undefined ],
 [new Date(2010,8,1), 121.69, undefined, undefined, undefined ]
 ]); }