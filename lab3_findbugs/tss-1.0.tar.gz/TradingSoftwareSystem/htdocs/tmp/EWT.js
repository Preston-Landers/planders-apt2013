
function addChartData(data) {
data.addRows([
 [new Date(2010,7,2), 12.79, undefined, undefined, undefined ],
 [new Date(2010,7,3), 12.83, undefined, undefined, undefined ],
 [new Date(2010,7,4), 12.79, undefined, undefined, undefined ],
 [new Date(2010,7,5), 12.71, undefined, undefined, undefined ],
 [new Date(2010,7,6), 12.7, undefined, undefined, undefined ],
 [new Date(2010,7,9), 12.87, undefined, undefined, undefined ],
 [new Date(2010,7,10), 12.76, undefined, undefined, undefined ],
 [new Date(2010,7,11), 12.44, undefined, undefined, undefined ],
 [new Date(2010,7,12), 12.46, undefined, undefined, undefined ],
 [new Date(2010,7,13), 12.55, undefined, undefined, undefined ],
 [new Date(2010,7,16), 12.62, undefined, undefined, undefined ],
 [new Date(2010,7,17), 12.65, undefined, undefined, undefined ],
 [new Date(2010,7,18), 12.64, undefined, undefined, undefined ],
 [new Date(2010,7,19), 12.52, undefined, undefined, undefined ],
 [new Date(2010,7,20), 12.56, undefined, undefined, undefined ],
 [new Date(2010,7,23), 12.62, undefined, undefined, undefined ],
 [new Date(2010,7,24), 12.49, undefined, undefined, undefined ],
 [new Date(2010,7,25), 12.3, undefined, undefined, undefined ],
 [new Date(2010,7,26), 12.19, undefined, undefined, undefined ],
 [new Date(2010,7,27), 12.36, undefined, undefined, undefined ],
 [new Date(2010,7,30), 12.23, undefined, undefined, undefined ],
 [new Date(2010,7,31), 12.14, undefined, undefined, undefined ],
 [new Date(2010,8,1), 12.36, undefined, undefined, undefined ]
 ]); }