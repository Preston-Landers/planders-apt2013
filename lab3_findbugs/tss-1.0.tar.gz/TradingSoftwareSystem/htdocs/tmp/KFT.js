
function addChartData(data) {
data.addRows([
 [new Date(2010,7,2), 29.49, undefined, undefined, undefined ],
 [new Date(2010,7,3), 29.28, undefined, undefined, undefined ],
 [new Date(2010,7,4), 29.75, undefined, undefined, undefined ],
 [new Date(2010,7,5), 29.66, undefined, undefined, undefined ],
 [new Date(2010,7,6), 30.36, undefined, undefined, undefined ],
 [new Date(2010,7,9), 30.39, undefined, undefined, undefined ],
 [new Date(2010,7,10), 30.27, undefined, undefined, undefined ],
 [new Date(2010,7,11), 29.58, undefined, undefined, undefined ],
 [new Date(2010,7,12), 29.5, undefined, undefined, undefined ],
 [new Date(2010,7,13), 29.5, undefined, undefined, undefined ],
 [new Date(2010,7,16), 29.45, undefined, undefined, undefined ],
 [new Date(2010,7,17), 29.26, undefined, undefined, undefined ],
 [new Date(2010,7,18), 29.34, undefined, undefined, undefined ],
 [new Date(2010,7,19), 29.13, undefined, undefined, undefined ],
 [new Date(2010,7,20), 29.1, undefined, undefined, undefined ],
 [new Date(2010,7,23), 29.15, undefined, undefined, undefined ],
 [new Date(2010,7,24), 29.29, undefined, undefined, undefined ],
 [new Date(2010,7,25), 29.59, undefined, undefined, undefined ],
 [new Date(2010,7,26), 29.42, undefined, undefined, undefined ],
 [new Date(2010,7,27), 30.0, undefined, undefined, undefined ],
 [new Date(2010,7,30), 29.7, undefined, undefined, undefined ],
 [new Date(2010,7,31), 29.91, undefined, undefined, undefined ],
 [new Date(2010,8,1), 30.38, undefined, undefined, undefined ]
 ]); }