
function addChartData(data) {
data.addRows([
 [new Date(2010,7,2), 16.23, undefined, undefined, undefined ],
 [new Date(2010,7,3), 16.17, undefined, undefined, undefined ],
 [new Date(2010,7,4), 16.06, undefined, undefined, undefined ],
 [new Date(2010,7,5), 16.19, undefined, undefined, undefined ],
 [new Date(2010,7,6), 16.89, undefined, undefined, undefined ],
 [new Date(2010,7,9), 17.06, undefined, undefined, undefined ],
 [new Date(2010,7,10), 17.16, undefined, undefined, undefined ],
 [new Date(2010,7,11), 16.96, undefined, undefined, undefined ],
 [new Date(2010,7,12), 17.17, undefined, undefined, undefined ],
 [new Date(2010,7,13), 17.36, undefined, undefined, undefined ],
 [new Date(2010,7,16), 17.4, undefined, undefined, undefined ],
 [new Date(2010,7,17), 17.34, undefined, undefined, undefined ],
 [new Date(2010,7,18), 17.14, undefined, undefined, undefined ],
 [new Date(2010,7,19), 17.04, undefined, undefined, undefined ],
 [new Date(2010,7,20), 17.04, undefined, undefined, undefined ],
 [new Date(2010,7,23), 17.33, undefined, undefined, undefined ],
 [new Date(2010,7,24), 17.5, undefined, undefined, undefined ],
 [new Date(2010,7,25), 17.5, undefined, undefined, undefined ],
 [new Date(2010,7,26), 17.47, undefined, undefined, undefined ],
 [new Date(2010,7,27), 17.76, undefined, undefined, undefined ],
 [new Date(2010,7,30), 17.43, undefined, undefined, undefined ],
 [new Date(2010,7,31), 17.5, undefined, undefined, undefined ],
 [new Date(2010,8,1), 17.84, undefined, undefined, undefined ]
 ]); }