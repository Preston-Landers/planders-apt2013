
function addChartData(data) {
data.addRows([
 [new Date(2010,7,2), 37.71, undefined, undefined, undefined ],
 [new Date(2010,7,3), 37.63, undefined, undefined, undefined ],
 [new Date(2010,7,4), 37.77, undefined, undefined, undefined ],
 [new Date(2010,7,5), 37.29, undefined, undefined, undefined ],
 [new Date(2010,7,6), 36.87, undefined, undefined, undefined ],
 [new Date(2010,7,9), 36.73, undefined, undefined, undefined ],
 [new Date(2010,7,10), 37.26, undefined, undefined, undefined ],
 [new Date(2010,7,11), 36.85, undefined, undefined, undefined ],
 [new Date(2010,7,12), 36.99, undefined, undefined, undefined ],
 [new Date(2010,7,13), 36.84, undefined, undefined, undefined ],
 [new Date(2010,7,16), 36.82, undefined, undefined, undefined ],
 [new Date(2010,7,17), 36.77, undefined, undefined, undefined ],
 [new Date(2010,7,18), 36.92, undefined, undefined, undefined ],
 [new Date(2010,7,19), 36.8, undefined, undefined, undefined ],
 [new Date(2010,7,20), 36.76, undefined, undefined, undefined ],
 [new Date(2010,7,23), 36.53, undefined, undefined, undefined ],
 [new Date(2010,7,24), 36.9, undefined, undefined, undefined ],
 [new Date(2010,7,25), 37.22, undefined, undefined, undefined ],
 [new Date(2010,7,26), 37.07, undefined, undefined, undefined ],
 [new Date(2010,7,27), 37.38, undefined, undefined, undefined ],
 [new Date(2010,7,30), 37.0, undefined, undefined, undefined ],
 [new Date(2010,7,31), 36.82, undefined, undefined, undefined ],
 [new Date(2010,8,1), 37.71, undefined, undefined, undefined ]
 ]); }