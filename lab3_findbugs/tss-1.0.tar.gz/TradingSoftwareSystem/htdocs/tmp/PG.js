
function addChartData(data) {
data.addRows([
 [new Date(2010,7,2), 62.06, undefined, undefined, undefined ],
 [new Date(2010,7,3), 59.94, undefined, undefined, undefined ],
 [new Date(2010,7,4), 59.55, undefined, undefined, undefined ],
 [new Date(2010,7,5), 59.86, undefined, undefined, undefined ],
 [new Date(2010,7,6), 60.02, undefined, undefined, undefined ],
 [new Date(2010,7,9), 60.38, undefined, undefined, undefined ],
 [new Date(2010,7,10), 60.78, undefined, undefined, undefined ],
 [new Date(2010,7,11), 60.27, undefined, undefined, undefined ],
 [new Date(2010,7,12), 59.99, undefined, undefined, undefined ],
 [new Date(2010,7,13), 59.82, undefined, undefined, undefined ],
 [new Date(2010,7,16), 59.77, undefined, undefined, undefined ],
 [new Date(2010,7,17), 60.29, undefined, undefined, undefined ],
 [new Date(2010,7,18), 60.75, undefined, undefined, undefined ],
 [new Date(2010,7,19), 60.19, undefined, undefined, undefined ],
 [new Date(2010,7,20), 59.98, undefined, undefined, undefined ],
 [new Date(2010,7,23), 60.03, undefined, undefined, undefined ],
 [new Date(2010,7,24), 59.66, undefined, undefined, undefined ],
 [new Date(2010,7,25), 59.67, undefined, undefined, undefined ],
 [new Date(2010,7,26), 59.54, undefined, undefined, undefined ],
 [new Date(2010,7,27), 59.8, undefined, undefined, undefined ],
 [new Date(2010,7,30), 59.37, undefined, undefined, undefined ],
 [new Date(2010,7,31), 59.67, undefined, undefined, undefined ],
 [new Date(2010,8,1), 59.8, undefined, undefined, undefined ]
 ]); }