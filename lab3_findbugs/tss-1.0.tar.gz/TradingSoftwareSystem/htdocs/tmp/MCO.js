
function addChartData(data) {
data.addRows([
 [new Date(2010,7,2), 23.61, undefined, undefined, undefined ],
 [new Date(2010,7,3), 23.88, undefined, undefined, undefined ],
 [new Date(2010,7,4), 24.06, undefined, undefined, undefined ],
 [new Date(2010,7,5), 23.85, undefined, undefined, undefined ],
 [new Date(2010,7,6), 23.53, undefined, undefined, undefined ],
 [new Date(2010,7,9), 23.64, undefined, undefined, undefined ],
 [new Date(2010,7,10), 23.33, undefined, undefined, undefined ],
 [new Date(2010,7,11), 22.32, undefined, undefined, undefined ],
 [new Date(2010,7,12), 22.22, undefined, undefined, undefined ],
 [new Date(2010,7,13), 21.9, undefined, undefined, undefined ],
 [new Date(2010,7,16), 22.26, undefined, undefined, undefined ],
 [new Date(2010,7,17), 22.24, undefined, undefined, undefined ],
 [new Date(2010,7,18), 22.54, undefined, undefined, undefined ],
 [new Date(2010,7,19), 22.02, undefined, undefined, undefined ],
 [new Date(2010,7,20), 21.71, undefined, undefined, undefined ],
 [new Date(2010,7,23), 21.5, undefined, undefined, undefined ],
 [new Date(2010,7,24), 21.1, undefined, undefined, undefined ],
 [new Date(2010,7,25), 21.24, undefined, undefined, undefined ],
 [new Date(2010,7,26), 21.07, undefined, undefined, undefined ],
 [new Date(2010,7,27), 21.44, undefined, undefined, undefined ],
 [new Date(2010,7,30), 21.18, undefined, undefined, undefined ],
 [new Date(2010,7,31), 21.14, undefined, undefined, undefined ],
 [new Date(2010,8,1), 21.95, undefined, undefined, undefined ]
 ]); }