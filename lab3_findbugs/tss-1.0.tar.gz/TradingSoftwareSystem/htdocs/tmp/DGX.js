
function addChartData(data) {
data.addRows([
 [new Date(2010,7,2), 48.12, undefined, undefined, undefined ],
 [new Date(2010,7,3), 47.47, undefined, undefined, undefined ],
 [new Date(2010,7,4), 48.28, undefined, undefined, undefined ],
 [new Date(2010,7,5), 48.2, undefined, undefined, undefined ],
 [new Date(2010,7,6), 48.11, undefined, undefined, undefined ],
 [new Date(2010,7,9), 48.38, undefined, undefined, undefined ],
 [new Date(2010,7,10), 48.8, undefined, undefined, undefined ],
 [new Date(2010,7,11), 47.34, undefined, undefined, undefined ],
 [new Date(2010,7,12), 47.41, undefined, undefined, undefined ],
 [new Date(2010,7,13), 47.36, undefined, undefined, undefined ],
 [new Date(2010,7,16), 47.08, undefined, undefined, undefined ],
 [new Date(2010,7,17), 47.7, undefined, undefined, undefined ],
 [new Date(2010,7,18), 47.62, undefined, undefined, undefined ],
 [new Date(2010,7,19), 46.26, undefined, undefined, undefined ],
 [new Date(2010,7,20), 46.38, undefined, undefined, undefined ],
 [new Date(2010,7,23), 46.19, undefined, undefined, undefined ],
 [new Date(2010,7,24), 45.12, undefined, undefined, undefined ],
 [new Date(2010,7,25), 45.38, undefined, undefined, undefined ],
 [new Date(2010,7,26), 44.74, undefined, undefined, undefined ],
 [new Date(2010,7,27), 44.65, undefined, undefined, undefined ],
 [new Date(2010,7,30), 44.33, undefined, undefined, undefined ],
 [new Date(2010,7,31), 43.5, undefined, undefined, undefined ],
 [new Date(2010,8,1), 44.92, undefined, undefined, undefined ]
 ]); }