
function addChartData(data) {
data.addRows([
 [new Date(2010,7,2), 36.27, undefined, undefined, undefined ],
 [new Date(2010,7,3), 36.25, undefined, undefined, undefined ],
 [new Date(2010,7,4), 35.99, undefined, undefined, undefined ],
 [new Date(2010,7,5), 36.41, undefined, undefined, undefined ],
 [new Date(2010,7,6), 35.98, undefined, undefined, undefined ],
 [new Date(2010,7,9), 35.85, undefined, undefined, undefined ],
 [new Date(2010,7,10), 36.27, undefined, undefined, undefined ],
 [new Date(2010,7,11), 35.5, undefined, undefined, undefined ],
 [new Date(2010,7,12), 35.35, undefined, undefined, undefined ],
 [new Date(2010,7,13), 35.52, undefined, undefined, undefined ],
 [new Date(2010,7,16), 35.73, undefined, undefined, undefined ],
 [new Date(2010,7,17), 35.76, undefined, undefined, undefined ],
 [new Date(2010,7,18), 35.22, undefined, undefined, undefined ],
 [new Date(2010,7,19), 34.84, undefined, undefined, undefined ],
 [new Date(2010,7,20), 34.82, undefined, undefined, undefined ],
 [new Date(2010,7,23), 35.11, undefined, undefined, undefined ],
 [new Date(2010,7,24), 35.41, undefined, undefined, undefined ],
 [new Date(2010,7,25), 35.33, undefined, undefined, undefined ],
 [new Date(2010,7,26), 35.2, undefined, undefined, undefined ],
 [new Date(2010,7,27), 35.71, undefined, undefined, undefined ],
 [new Date(2010,7,30), 35.17, undefined, undefined, undefined ],
 [new Date(2010,7,31), 35.41, undefined, undefined, undefined ],
 [new Date(2010,8,1), 36.11, undefined, undefined, undefined ]
 ]); }