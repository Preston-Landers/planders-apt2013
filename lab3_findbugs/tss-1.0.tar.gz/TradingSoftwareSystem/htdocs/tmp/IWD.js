
function addChartData(data) {
data.addRows([
 [new Date(2010,7,2), 58.85, undefined, undefined, undefined ],
 [new Date(2010,7,3), 58.54, undefined, undefined, undefined ],
 [new Date(2010,7,4), 58.84, undefined, undefined, undefined ],
 [new Date(2010,7,5), 58.77, undefined, undefined, undefined ],
 [new Date(2010,7,6), 58.54, undefined, undefined, undefined ],
 [new Date(2010,7,9), 58.87, undefined, undefined, undefined ],
 [new Date(2010,7,10), 58.53, undefined, undefined, undefined ],
 [new Date(2010,7,11), 56.82, undefined, undefined, undefined ],
 [new Date(2010,7,12), 56.61, undefined, undefined, undefined ],
 [new Date(2010,7,13), 56.48, undefined, undefined, undefined ],
 [new Date(2010,7,16), 56.47, undefined, undefined, undefined ],
 [new Date(2010,7,17), 57.1, undefined, undefined, undefined ],
 [new Date(2010,7,18), 57.19, undefined, undefined, undefined ],
 [new Date(2010,7,19), 56.12, undefined, undefined, undefined ],
 [new Date(2010,7,20), 55.89, undefined, undefined, undefined ],
 [new Date(2010,7,23), 55.7, undefined, undefined, undefined ],
 [new Date(2010,7,24), 54.99, undefined, undefined, undefined ],
 [new Date(2010,7,25), 55.16, undefined, undefined, undefined ],
 [new Date(2010,7,26), 54.83, undefined, undefined, undefined ],
 [new Date(2010,7,27), 55.79, undefined, undefined, undefined ],
 [new Date(2010,7,30), 54.95, undefined, undefined, undefined ],
 [new Date(2010,7,31), 55.13, undefined, undefined, undefined ],
 [new Date(2010,8,1), 56.81, undefined, undefined, undefined ]
 ]); }