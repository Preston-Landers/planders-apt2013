
function addChartData(data) {
data.addRows([
 [new Date(2010,7,2), 64.7, undefined, undefined, undefined ],
 [new Date(2010,7,3), 64.47, undefined, undefined, undefined ],
 [new Date(2010,7,4), 64.9, undefined, undefined, undefined ],
 [new Date(2010,7,5), 64.92, undefined, undefined, undefined ],
 [new Date(2010,7,6), 65.08, undefined, undefined, undefined ],
 [new Date(2010,7,9), 65.87, undefined, undefined, undefined ],
 [new Date(2010,7,10), 65.88, undefined, undefined, undefined ],
 [new Date(2010,7,11), 64.63, undefined, undefined, undefined ],
 [new Date(2010,7,12), 64.52, undefined, undefined, undefined ],
 [new Date(2010,7,13), 64.31, undefined, undefined, undefined ],
 [new Date(2010,7,16), 64.25, undefined, undefined, undefined ],
 [new Date(2010,7,17), 64.85, undefined, undefined, undefined ],
 [new Date(2010,7,18), 65.16, undefined, undefined, undefined ],
 [new Date(2010,7,19), 64.4, undefined, undefined, undefined ],
 [new Date(2010,7,20), 64.42, undefined, undefined, undefined ],
 [new Date(2010,7,23), 64.3, undefined, undefined, undefined ],
 [new Date(2010,7,24), 64.61, undefined, undefined, undefined ],
 [new Date(2010,7,25), 64.41, undefined, undefined, undefined ],
 [new Date(2010,7,26), 64.15, undefined, undefined, undefined ],
 [new Date(2010,7,27), 64.68, undefined, undefined, undefined ],
 [new Date(2010,7,30), 64.26, undefined, undefined, undefined ],
 [new Date(2010,7,31), 64.82, undefined, undefined, undefined ],
 [new Date(2010,8,1), 65.37, undefined, undefined, undefined ]
 ]); }