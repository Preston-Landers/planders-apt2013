
function addChartData(data) {
data.addRows([
 [new Date(2010,7,2), 55.37, undefined, undefined, undefined ],
 [new Date(2010,7,3), 55.11, undefined, undefined, undefined ],
 [new Date(2010,7,4), 55.21, undefined, undefined, undefined ],
 [new Date(2010,7,5), 55.46, undefined, undefined, undefined ],
 [new Date(2010,7,6), 55.84, undefined, undefined, undefined ],
 [new Date(2010,7,9), 55.95, undefined, undefined, undefined ],
 [new Date(2010,7,10), 56.12, undefined, undefined, undefined ],
 [new Date(2010,7,11), 55.19, undefined, undefined, undefined ],
 [new Date(2010,7,12), 55.05, undefined, undefined, undefined ],
 [new Date(2010,7,13), 55.22, undefined, undefined, undefined ],
 [new Date(2010,7,16), 55.36, undefined, undefined, undefined ],
 [new Date(2010,7,17), 56.07, undefined, undefined, undefined ],
 [new Date(2010,7,18), 56.18, undefined, undefined, undefined ],
 [new Date(2010,7,19), 55.56, undefined, undefined, undefined ],
 [new Date(2010,7,20), 55.63, undefined, undefined, undefined ],
 [new Date(2010,7,23), 55.7, undefined, undefined, undefined ],
 [new Date(2010,7,24), 55.85, undefined, undefined, undefined ],
 [new Date(2010,7,25), 55.87, undefined, undefined, undefined ],
 [new Date(2010,7,26), 55.4, undefined, undefined, undefined ],
 [new Date(2010,7,27), 56.52, undefined, undefined, undefined ],
 [new Date(2010,7,30), 55.65, undefined, undefined, undefined ],
 [new Date(2010,7,31), 55.74, undefined, undefined, undefined ],
 [new Date(2010,8,1), 56.98, undefined, undefined, undefined ]
 ]); }