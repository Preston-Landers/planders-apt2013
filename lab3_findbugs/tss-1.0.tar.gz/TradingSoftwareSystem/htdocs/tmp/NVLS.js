
function addChartData(data) {
data.addRows([
 [new Date(2010,7,2), 27.06, undefined, undefined, undefined ],
 [new Date(2010,7,3), 26.31, undefined, undefined, undefined ],
 [new Date(2010,7,4), 26.59, undefined, undefined, undefined ],
 [new Date(2010,7,5), 26.56, undefined, undefined, undefined ],
 [new Date(2010,7,6), 26.45, undefined, undefined, undefined ],
 [new Date(2010,7,9), 26.7, undefined, undefined, undefined ],
 [new Date(2010,7,10), 25.89, undefined, undefined, undefined ],
 [new Date(2010,7,11), 25.11, undefined, undefined, undefined ],
 [new Date(2010,7,12), 24.78, undefined, undefined, undefined ],
 [new Date(2010,7,13), 24.66, undefined, undefined, undefined ],
 [new Date(2010,7,16), 24.75, undefined, undefined, undefined ],
 [new Date(2010,7,17), 25.04, undefined, undefined, undefined ],
 [new Date(2010,7,18), 25.31, undefined, undefined, undefined ],
 [new Date(2010,7,19), 25.03, undefined, undefined, undefined ],
 [new Date(2010,7,20), 24.81, undefined, undefined, undefined ],
 [new Date(2010,7,23), 24.67, undefined, undefined, undefined ],
 [new Date(2010,7,24), 24.09, undefined, undefined, undefined ],
 [new Date(2010,7,25), 24.32, undefined, undefined, undefined ],
 [new Date(2010,7,26), 23.71, undefined, undefined, undefined ],
 [new Date(2010,7,27), 24.11, undefined, undefined, undefined ],
 [new Date(2010,7,30), 23.25, undefined, undefined, undefined ],
 [new Date(2010,7,31), 23.29, undefined, undefined, undefined ],
 [new Date(2010,8,1), 23.66, undefined, undefined, undefined ]
 ]); }