
function addChartData(data) {
data.addRows([
 [new Date(2010,7,2), 42.85, undefined, undefined, undefined ],
 [new Date(2010,7,3), 42.73, undefined, undefined, undefined ],
 [new Date(2010,7,4), 42.7, undefined, undefined, undefined ],
 [new Date(2010,7,5), 42.71, undefined, undefined, undefined ],
 [new Date(2010,7,6), 42.32, undefined, undefined, undefined ],
 [new Date(2010,7,9), 42.69, undefined, undefined, undefined ],
 [new Date(2010,7,10), 43.05, undefined, undefined, undefined ],
 [new Date(2010,7,11), 42.39, undefined, undefined, undefined ],
 [new Date(2010,7,12), 42.53, undefined, undefined, undefined ],
 [new Date(2010,7,13), 42.7, undefined, undefined, undefined ],
 [new Date(2010,7,16), 42.72, undefined, undefined, undefined ],
 [new Date(2010,7,17), 43.11, undefined, undefined, undefined ],
 [new Date(2010,7,18), 42.7, undefined, undefined, undefined ],
 [new Date(2010,7,19), 41.89, undefined, undefined, undefined ],
 [new Date(2010,7,20), 42.14, undefined, undefined, undefined ],
 [new Date(2010,7,23), 42.38, undefined, undefined, undefined ],
 [new Date(2010,7,24), 42.85, undefined, undefined, undefined ],
 [new Date(2010,7,25), 42.93, undefined, undefined, undefined ],
 [new Date(2010,7,26), 42.68, undefined, undefined, undefined ],
 [new Date(2010,7,27), 43.37, undefined, undefined, undefined ],
 [new Date(2010,7,30), 42.74, undefined, undefined, undefined ],
 [new Date(2010,7,31), 42.91, undefined, undefined, undefined ],
 [new Date(2010,8,1), 43.83, undefined, undefined, undefined ]
 ]); }