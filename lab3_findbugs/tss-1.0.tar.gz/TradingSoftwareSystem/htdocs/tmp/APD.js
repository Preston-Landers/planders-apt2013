
function addChartData(data) {
data.addRows([
 [new Date(2010,7,2), 74.99, undefined, undefined, undefined ],
 [new Date(2010,7,3), 75.68, undefined, undefined, undefined ],
 [new Date(2010,7,4), 76.7, undefined, undefined, undefined ],
 [new Date(2010,7,5), 77.06, undefined, undefined, undefined ],
 [new Date(2010,7,6), 76.22, undefined, undefined, undefined ],
 [new Date(2010,7,9), 77.0, undefined, undefined, undefined ],
 [new Date(2010,7,10), 76.93, undefined, undefined, undefined ],
 [new Date(2010,7,11), 75.4, undefined, undefined, undefined ],
 [new Date(2010,7,12), 74.7, undefined, undefined, undefined ],
 [new Date(2010,7,13), 75.68, undefined, undefined, undefined ],
 [new Date(2010,7,16), 75.9, undefined, undefined, undefined ],
 [new Date(2010,7,17), 76.72, undefined, undefined, undefined ],
 [new Date(2010,7,18), 77.03, undefined, undefined, undefined ],
 [new Date(2010,7,19), 75.59, undefined, undefined, undefined ],
 [new Date(2010,7,20), 75.01, undefined, undefined, undefined ],
 [new Date(2010,7,23), 74.69, undefined, undefined, undefined ],
 [new Date(2010,7,24), 73.84, undefined, undefined, undefined ],
 [new Date(2010,7,25), 73.55, undefined, undefined, undefined ],
 [new Date(2010,7,26), 73.56, undefined, undefined, undefined ],
 [new Date(2010,7,27), 74.42, undefined, undefined, undefined ],
 [new Date(2010,7,30), 73.7, undefined, undefined, undefined ],
 [new Date(2010,7,31), 74.03, undefined, undefined, undefined ],
 [new Date(2010,8,1), 74.75, undefined, undefined, undefined ]
 ]); }