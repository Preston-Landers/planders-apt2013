
function addChartData(data) {
data.addRows([
 [new Date(2010,7,2), 25.53, undefined, undefined, undefined ],
 [new Date(2010,7,3), 25.68, undefined, undefined, undefined ],
 [new Date(2010,7,4), 26.03, undefined, undefined, undefined ],
 [new Date(2010,7,5), 26.38, undefined, undefined, undefined ],
 [new Date(2010,7,6), 26.37, undefined, undefined, undefined ],
 [new Date(2010,7,9), 26.51, undefined, undefined, undefined ],
 [new Date(2010,7,10), 26.66, undefined, undefined, undefined ],
 [new Date(2010,7,11), 26.25, undefined, undefined, undefined ],
 [new Date(2010,7,12), 26.33, undefined, undefined, undefined ],
 [new Date(2010,7,13), 26.32, undefined, undefined, undefined ],
 [new Date(2010,7,16), 26.28, undefined, undefined, undefined ],
 [new Date(2010,7,17), 26.59, undefined, undefined, undefined ],
 [new Date(2010,7,18), 26.28, undefined, undefined, undefined ],
 [new Date(2010,7,19), 26.06, undefined, undefined, undefined ],
 [new Date(2010,7,20), 26.44, undefined, undefined, undefined ],
 [new Date(2010,7,23), 26.48, undefined, undefined, undefined ],
 [new Date(2010,7,24), 26.02, undefined, undefined, undefined ],
 [new Date(2010,7,25), 26.08, undefined, undefined, undefined ],
 [new Date(2010,7,26), 25.85, undefined, undefined, undefined ],
 [new Date(2010,7,27), 26.12, undefined, undefined, undefined ],
 [new Date(2010,7,30), 25.85, undefined, undefined, undefined ],
 [new Date(2010,7,31), 26.08, undefined, undefined, undefined ],
 [new Date(2010,8,1), 26.41, undefined, undefined, undefined ]
 ]); }