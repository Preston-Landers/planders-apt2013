
function addChartData(data) {
data.addRows([
 [new Date(2010,7,2), 64.72, undefined, undefined, undefined ],
 [new Date(2010,7,3), 63.48, undefined, undefined, undefined ],
 [new Date(2010,7,4), 63.72, undefined, undefined, undefined ],
 [new Date(2010,7,5), 64.02, undefined, undefined, undefined ],
 [new Date(2010,7,6), 64.76, undefined, undefined, undefined ],
 [new Date(2010,7,9), 64.56, undefined, undefined, undefined ],
 [new Date(2010,7,10), 64.21, undefined, undefined, undefined ],
 [new Date(2010,7,11), 63.02, undefined, undefined, undefined ],
 [new Date(2010,7,12), 63.44, undefined, undefined, undefined ],
 [new Date(2010,7,13), 63.66, undefined, undefined, undefined ],
 [new Date(2010,7,16), 62.97, undefined, undefined, undefined ],
 [new Date(2010,7,17), 63.93, undefined, undefined, undefined ],
 [new Date(2010,7,18), 63.9, undefined, undefined, undefined ],
 [new Date(2010,7,19), 63.06, undefined, undefined, undefined ],
 [new Date(2010,7,20), 62.96, undefined, undefined, undefined ],
 [new Date(2010,7,23), 63.84, undefined, undefined, undefined ],
 [new Date(2010,7,24), 63.11, undefined, undefined, undefined ],
 [new Date(2010,7,25), 63.36, undefined, undefined, undefined ],
 [new Date(2010,7,26), 63.22, undefined, undefined, undefined ],
 [new Date(2010,7,27), 63.17, undefined, undefined, undefined ],
 [new Date(2010,7,30), 62.01, undefined, undefined, undefined ],
 [new Date(2010,7,31), 61.42, undefined, undefined, undefined ],
 [new Date(2010,8,1), 63.28, undefined, undefined, undefined ]
 ]); }