
function addChartData(data) {
data.addRows([
 [new Date(2010,7,2), 65.27, undefined, undefined, undefined ],
 [new Date(2010,7,3), 65.77, undefined, undefined, undefined ],
 [new Date(2010,7,4), 66.17, undefined, undefined, undefined ],
 [new Date(2010,7,5), 65.58, undefined, undefined, undefined ],
 [new Date(2010,7,6), 65.9, undefined, undefined, undefined ],
 [new Date(2010,7,9), 66.42, undefined, undefined, undefined ],
 [new Date(2010,7,10), 66.53, undefined, undefined, undefined ],
 [new Date(2010,7,11), 65.45, undefined, undefined, undefined ],
 [new Date(2010,7,12), 65.18, undefined, undefined, undefined ],
 [new Date(2010,7,13), 65.56, undefined, undefined, undefined ],
 [new Date(2010,7,16), 65.43, undefined, undefined, undefined ],
 [new Date(2010,7,17), 65.55, undefined, undefined, undefined ],
 [new Date(2010,7,18), 65.52, undefined, undefined, undefined ],
 [new Date(2010,7,19), 64.66, undefined, undefined, undefined ],
 [new Date(2010,7,20), 64.8, undefined, undefined, undefined ],
 [new Date(2010,7,23), 64.82, undefined, undefined, undefined ],
 [new Date(2010,7,24), 64.78, undefined, undefined, undefined ],
 [new Date(2010,7,25), 64.57, undefined, undefined, undefined ],
 [new Date(2010,7,26), 64.13, undefined, undefined, undefined ],
 [new Date(2010,7,27), 64.12, undefined, undefined, undefined ],
 [new Date(2010,7,30), 63.6, undefined, undefined, undefined ],
 [new Date(2010,7,31), 64.18, undefined, undefined, undefined ],
 [new Date(2010,8,1), 64.89, undefined, undefined, undefined ]
 ]); }