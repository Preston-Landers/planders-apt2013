
function addChartData(data) {
data.addRows([
 [new Date(2010,7,2), 75.9, undefined, undefined, undefined ],
 [new Date(2010,7,3), 75.43, undefined, undefined, undefined ],
 [new Date(2010,7,4), 75.02, undefined, undefined, undefined ],
 [new Date(2010,7,5), 75.03, undefined, undefined, undefined ],
 [new Date(2010,7,6), 75.07, undefined, undefined, undefined ],
 [new Date(2010,7,9), 75.6, undefined, undefined, undefined ],
 [new Date(2010,7,10), 75.05, undefined, undefined, undefined ],
 [new Date(2010,7,11), 73.12, undefined, undefined, undefined ],
 [new Date(2010,7,12), 72.48, undefined, undefined, undefined ],
 [new Date(2010,7,13), 72.72, undefined, undefined, undefined ],
 [new Date(2010,7,16), 71.94, undefined, undefined, undefined ],
 [new Date(2010,7,17), 72.42, undefined, undefined, undefined ],
 [new Date(2010,7,18), 73.66, undefined, undefined, undefined ],
 [new Date(2010,7,19), 73.08, undefined, undefined, undefined ],
 [new Date(2010,7,20), 73.2, undefined, undefined, undefined ],
 [new Date(2010,7,23), 72.48, undefined, undefined, undefined ],
 [new Date(2010,7,24), 71.25, undefined, undefined, undefined ],
 [new Date(2010,7,25), 71.67, undefined, undefined, undefined ],
 [new Date(2010,7,26), 71.54, undefined, undefined, undefined ],
 [new Date(2010,7,27), 72.27, undefined, undefined, undefined ],
 [new Date(2010,7,30), 70.22, undefined, undefined, undefined ],
 [new Date(2010,7,31), 69.52, undefined, undefined, undefined ],
 [new Date(2010,8,1), 69.93, undefined, undefined, undefined ]
 ]); }