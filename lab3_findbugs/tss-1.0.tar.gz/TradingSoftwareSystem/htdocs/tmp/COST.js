
function addChartData(data) {
data.addRows([
 [new Date(2010,7,2), 56.84, undefined, undefined, undefined ],
 [new Date(2010,7,3), 56.55, undefined, undefined, undefined ],
 [new Date(2010,7,4), 57.4, undefined, undefined, undefined ],
 [new Date(2010,7,5), 56.46, undefined, undefined, undefined ],
 [new Date(2010,7,6), 56.54, undefined, undefined, undefined ],
 [new Date(2010,7,9), 57.16, undefined, undefined, undefined ],
 [new Date(2010,7,10), 56.98, undefined, undefined, undefined ],
 [new Date(2010,7,11), 55.87, undefined, undefined, undefined ],
 [new Date(2010,7,12), 55.67, undefined, undefined, undefined ],
 [new Date(2010,7,13), 55.31, undefined, undefined, undefined ],
 [new Date(2010,7,16), 55.37, undefined, undefined, undefined ],
 [new Date(2010,7,17), 55.83, undefined, undefined, undefined ],
 [new Date(2010,7,18), 55.68, undefined, undefined, undefined ],
 [new Date(2010,7,19), 55.01, undefined, undefined, undefined ],
 [new Date(2010,7,20), 55.04, undefined, undefined, undefined ],
 [new Date(2010,7,23), 54.9, undefined, undefined, undefined ],
 [new Date(2010,7,24), 55.6, undefined, undefined, undefined ],
 [new Date(2010,7,25), 57.07, undefined, undefined, undefined ],
 [new Date(2010,7,26), 56.28, undefined, undefined, undefined ],
 [new Date(2010,7,27), 56.19, undefined, undefined, undefined ],
 [new Date(2010,7,30), 56.07, undefined, undefined, undefined ],
 [new Date(2010,7,31), 56.5, undefined, undefined, undefined ],
 [new Date(2010,8,1), 57.79, undefined, undefined, undefined ]
 ]); }