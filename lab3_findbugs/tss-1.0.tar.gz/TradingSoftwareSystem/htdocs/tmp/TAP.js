
function addChartData(data) {
data.addRows([
 [new Date(2010,7,2), 46.0, undefined, undefined, undefined ],
 [new Date(2010,7,3), 46.76, undefined, undefined, undefined ],
 [new Date(2010,7,4), 47.09, undefined, undefined, undefined ],
 [new Date(2010,7,5), 46.75, undefined, undefined, undefined ],
 [new Date(2010,7,6), 45.68, undefined, undefined, undefined ],
 [new Date(2010,7,9), 46.01, undefined, undefined, undefined ],
 [new Date(2010,7,10), 46.18, undefined, undefined, undefined ],
 [new Date(2010,7,11), 45.62, undefined, undefined, undefined ],
 [new Date(2010,7,12), 45.77, undefined, undefined, undefined ],
 [new Date(2010,7,13), 45.62, undefined, undefined, undefined ],
 [new Date(2010,7,16), 45.66, undefined, undefined, undefined ],
 [new Date(2010,7,17), 46.41, undefined, undefined, undefined ],
 [new Date(2010,7,18), 46.54, undefined, undefined, undefined ],
 [new Date(2010,7,19), 46.04, undefined, undefined, undefined ],
 [new Date(2010,7,20), 45.92, undefined, undefined, undefined ],
 [new Date(2010,7,23), 45.75, undefined, undefined, undefined ],
 [new Date(2010,7,24), 45.1, undefined, undefined, undefined ],
 [new Date(2010,7,25), 44.62, undefined, undefined, undefined ],
 [new Date(2010,7,26), 44.11, undefined, undefined, undefined ],
 [new Date(2010,7,27), 43.81, undefined, undefined, undefined ],
 [new Date(2010,7,30), 43.35, undefined, undefined, undefined ],
 [new Date(2010,7,31), 43.56, undefined, undefined, undefined ],
 [new Date(2010,8,1), 44.73, undefined, undefined, undefined ]
 ]); }