
function addChartData(data) {
data.addRows([
 [new Date(2010,7,2), 15.24, undefined, undefined, undefined ],
 [new Date(2010,7,3), 15.03, undefined, undefined, undefined ],
 [new Date(2010,7,4), 15.32, undefined, undefined, undefined ],
 [new Date(2010,7,5), 15.01, undefined, undefined, undefined ],
 [new Date(2010,7,6), 14.84, undefined, undefined, undefined ],
 [new Date(2010,7,9), 14.82, undefined, undefined, undefined ],
 [new Date(2010,7,10), 14.75, undefined, undefined, undefined ],
 [new Date(2010,7,11), 14.47, undefined, undefined, undefined ],
 [new Date(2010,7,12), 14.37, undefined, undefined, undefined ],
 [new Date(2010,7,13), 14.55, undefined, undefined, undefined ],
 [new Date(2010,7,16), 14.77, undefined, undefined, undefined ],
 [new Date(2010,7,17), 14.93, undefined, undefined, undefined ],
 [new Date(2010,7,18), 14.93, undefined, undefined, undefined ],
 [new Date(2010,7,19), 14.93, undefined, undefined, undefined ],
 [new Date(2010,7,20), 14.8, undefined, undefined, undefined ],
 [new Date(2010,7,23), 14.74, undefined, undefined, undefined ],
 [new Date(2010,7,24), 14.69, undefined, undefined, undefined ],
 [new Date(2010,7,25), 14.62, undefined, undefined, undefined ],
 [new Date(2010,7,26), 14.64, undefined, undefined, undefined ],
 [new Date(2010,7,27), 14.75, undefined, undefined, undefined ],
 [new Date(2010,7,30), 14.34, undefined, undefined, undefined ],
 [new Date(2010,7,31), 14.44, undefined, undefined, undefined ],
 [new Date(2010,8,1), 14.6, undefined, undefined, undefined ]
 ]); }