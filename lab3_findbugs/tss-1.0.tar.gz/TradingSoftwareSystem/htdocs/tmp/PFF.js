
function addChartData(data) {
data.addRows([
 [new Date(2010,7,2), 39.15, undefined, undefined, undefined ],
 [new Date(2010,7,3), 39.17, undefined, undefined, undefined ],
 [new Date(2010,7,4), 39.39, undefined, undefined, undefined ],
 [new Date(2010,7,5), 39.48, undefined, undefined, undefined ],
 [new Date(2010,7,6), 39.58, undefined, undefined, undefined ],
 [new Date(2010,7,9), 39.68, undefined, undefined, undefined ],
 [new Date(2010,7,10), 39.57, undefined, undefined, undefined ],
 [new Date(2010,7,11), 39.54, undefined, undefined, undefined ],
 [new Date(2010,7,12), 39.65, undefined, undefined, undefined ],
 [new Date(2010,7,13), 39.92, undefined, undefined, undefined ],
 [new Date(2010,7,16), 39.74, undefined, undefined, undefined ],
 [new Date(2010,7,17), 39.91, undefined, undefined, undefined ],
 [new Date(2010,7,18), 40.03, undefined, undefined, undefined ],
 [new Date(2010,7,19), 39.87, undefined, undefined, undefined ],
 [new Date(2010,7,20), 39.86, undefined, undefined, undefined ],
 [new Date(2010,7,23), 39.89, undefined, undefined, undefined ],
 [new Date(2010,7,24), 39.64, undefined, undefined, undefined ],
 [new Date(2010,7,25), 39.73, undefined, undefined, undefined ],
 [new Date(2010,7,26), 39.76, undefined, undefined, undefined ],
 [new Date(2010,7,27), 39.95, undefined, undefined, undefined ],
 [new Date(2010,7,30), 39.97, undefined, undefined, undefined ],
 [new Date(2010,7,31), 39.94, undefined, undefined, undefined ],
 [new Date(2010,8,1), 39.77, undefined, undefined, undefined ]
 ]); }