
function addChartData(data) {
data.addRows([
 [new Date(2010,7,2), 130.76, undefined, undefined, undefined ],
 [new Date(2010,7,3), 130.37, undefined, undefined, undefined ],
 [new Date(2010,7,4), 131.27, undefined, undefined, undefined ],
 [new Date(2010,7,5), 131.83, undefined, undefined, undefined ],
 [new Date(2010,7,6), 130.14, undefined, undefined, undefined ],
 [new Date(2010,7,9), 132.0, undefined, undefined, undefined ],
 [new Date(2010,7,10), 131.84, undefined, undefined, undefined ],
 [new Date(2010,7,11), 129.83, undefined, undefined, undefined ],
 [new Date(2010,7,12), 128.3, undefined, undefined, undefined ],
 [new Date(2010,7,13), 127.87, undefined, undefined, undefined ],
 [new Date(2010,7,16), 127.77, undefined, undefined, undefined ],
 [new Date(2010,7,17), 128.45, undefined, undefined, undefined ],
 [new Date(2010,7,18), 129.39, undefined, undefined, undefined ],
 [new Date(2010,7,19), 128.9, undefined, undefined, undefined ],
 [new Date(2010,7,20), 127.5, undefined, undefined, undefined ],
 [new Date(2010,7,23), 126.47, undefined, undefined, undefined ],
 [new Date(2010,7,24), 124.9, undefined, undefined, undefined ],
 [new Date(2010,7,25), 125.27, undefined, undefined, undefined ],
 [new Date(2010,7,26), 122.78, undefined, undefined, undefined ],
 [new Date(2010,7,27), 124.73, undefined, undefined, undefined ],
 [new Date(2010,7,30), 123.4, undefined, undefined, undefined ],
 [new Date(2010,7,31), 123.13, undefined, undefined, undefined ],
 [new Date(2010,8,1), 125.77, undefined, undefined, undefined ]
 ]); }