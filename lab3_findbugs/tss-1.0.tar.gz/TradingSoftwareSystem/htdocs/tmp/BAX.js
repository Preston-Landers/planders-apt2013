
function addChartData(data) {
data.addRows([
 [new Date(2010,7,2), 44.77, undefined, undefined, undefined ],
 [new Date(2010,7,3), 44.42, undefined, undefined, undefined ],
 [new Date(2010,7,4), 45.01, undefined, undefined, undefined ],
 [new Date(2010,7,5), 45.02, undefined, undefined, undefined ],
 [new Date(2010,7,6), 45.13, undefined, undefined, undefined ],
 [new Date(2010,7,9), 45.35, undefined, undefined, undefined ],
 [new Date(2010,7,10), 46.32, undefined, undefined, undefined ],
 [new Date(2010,7,11), 45.62, undefined, undefined, undefined ],
 [new Date(2010,7,12), 45.8, undefined, undefined, undefined ],
 [new Date(2010,7,13), 45.71, undefined, undefined, undefined ],
 [new Date(2010,7,16), 45.47, undefined, undefined, undefined ],
 [new Date(2010,7,17), 45.91, undefined, undefined, undefined ],
 [new Date(2010,7,18), 45.83, undefined, undefined, undefined ],
 [new Date(2010,7,19), 44.99, undefined, undefined, undefined ],
 [new Date(2010,7,20), 44.57, undefined, undefined, undefined ],
 [new Date(2010,7,23), 44.77, undefined, undefined, undefined ],
 [new Date(2010,7,24), 44.0, undefined, undefined, undefined ],
 [new Date(2010,7,25), 44.16, undefined, undefined, undefined ],
 [new Date(2010,7,26), 43.45, undefined, undefined, undefined ],
 [new Date(2010,7,27), 43.75, undefined, undefined, undefined ],
 [new Date(2010,7,30), 43.2, undefined, undefined, undefined ],
 [new Date(2010,7,31), 42.55, undefined, undefined, undefined ],
 [new Date(2010,8,1), 43.47, undefined, undefined, undefined ]
 ]); }