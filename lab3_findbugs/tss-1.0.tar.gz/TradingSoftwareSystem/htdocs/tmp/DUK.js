
function addChartData(data) {
data.addRows([
 [new Date(2010,7,2), 17.37, undefined, undefined, undefined ],
 [new Date(2010,7,3), 17.37, undefined, undefined, undefined ],
 [new Date(2010,7,4), 17.37, undefined, undefined, undefined ],
 [new Date(2010,7,5), 17.41, undefined, undefined, undefined ],
 [new Date(2010,7,6), 17.42, undefined, undefined, undefined ],
 [new Date(2010,7,9), 17.56, undefined, undefined, undefined ],
 [new Date(2010,7,10), 17.69, undefined, undefined, undefined ],
 [new Date(2010,7,11), 17.11, undefined, undefined, undefined ],
 [new Date(2010,7,12), 17.1, undefined, undefined, undefined ],
 [new Date(2010,7,13), 17.01, undefined, undefined, undefined ],
 [new Date(2010,7,16), 17.03, undefined, undefined, undefined ],
 [new Date(2010,7,17), 17.24, undefined, undefined, undefined ],
 [new Date(2010,7,18), 17.26, undefined, undefined, undefined ],
 [new Date(2010,7,19), 17.04, undefined, undefined, undefined ],
 [new Date(2010,7,20), 17.06, undefined, undefined, undefined ],
 [new Date(2010,7,23), 17.06, undefined, undefined, undefined ],
 [new Date(2010,7,24), 17.21, undefined, undefined, undefined ],
 [new Date(2010,7,25), 17.16, undefined, undefined, undefined ],
 [new Date(2010,7,26), 17.08, undefined, undefined, undefined ],
 [new Date(2010,7,27), 17.36, undefined, undefined, undefined ],
 [new Date(2010,7,30), 17.15, undefined, undefined, undefined ],
 [new Date(2010,7,31), 17.18, undefined, undefined, undefined ],
 [new Date(2010,8,1), 17.44, undefined, undefined, undefined ]
 ]); }