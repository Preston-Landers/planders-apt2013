
function addChartData(data) {
data.addRows([
 [new Date(2010,7,2), 109.63, undefined, undefined, undefined ],
 [new Date(2010,7,3), 109.9, undefined, undefined, undefined ],
 [new Date(2010,7,4), 109.56, undefined, undefined, undefined ],
 [new Date(2010,7,5), 109.76, undefined, undefined, undefined ],
 [new Date(2010,7,6), 110.39, undefined, undefined, undefined ],
 [new Date(2010,7,9), 110.75, undefined, undefined, undefined ],
 [new Date(2010,7,10), 110.61, undefined, undefined, undefined ],
 [new Date(2010,7,11), 110.6, undefined, undefined, undefined ],
 [new Date(2010,7,12), 110.21, undefined, undefined, undefined ],
 [new Date(2010,7,13), 110.64, undefined, undefined, undefined ],
 [new Date(2010,7,16), 111.86, undefined, undefined, undefined ],
 [new Date(2010,7,17), 111.68, undefined, undefined, undefined ],
 [new Date(2010,7,18), 111.78, undefined, undefined, undefined ],
 [new Date(2010,7,19), 111.9, undefined, undefined, undefined ],
 [new Date(2010,7,20), 112.1, undefined, undefined, undefined ],
 [new Date(2010,7,23), 112.34, undefined, undefined, undefined ],
 [new Date(2010,7,24), 112.6, undefined, undefined, undefined ],
 [new Date(2010,7,25), 112.81, undefined, undefined, undefined ],
 [new Date(2010,7,26), 112.91, undefined, undefined, undefined ],
 [new Date(2010,7,27), 111.89, undefined, undefined, undefined ],
 [new Date(2010,7,30), 112.62, undefined, undefined, undefined ],
 [new Date(2010,7,31), 113.0, undefined, undefined, undefined ],
 [new Date(2010,8,1), 111.73, undefined, undefined, undefined ]
 ]); }