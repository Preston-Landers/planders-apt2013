
function addChartData(data) {
data.addRows([
 [new Date(2010,7,2), 46.53, undefined, undefined, undefined ],
 [new Date(2010,7,3), 46.24, undefined, undefined, undefined ],
 [new Date(2010,7,4), 46.17, undefined, undefined, undefined ],
 [new Date(2010,7,5), 46.14, undefined, undefined, undefined ],
 [new Date(2010,7,6), 46.18, undefined, undefined, undefined ],
 [new Date(2010,7,9), 46.27, undefined, undefined, undefined ],
 [new Date(2010,7,10), 46.34, undefined, undefined, undefined ],
 [new Date(2010,7,11), 46.1, undefined, undefined, undefined ],
 [new Date(2010,7,12), 46.04, undefined, undefined, undefined ],
 [new Date(2010,7,13), 46.35, undefined, undefined, undefined ],
 [new Date(2010,7,16), 46.35, undefined, undefined, undefined ],
 [new Date(2010,7,17), 46.85, undefined, undefined, undefined ],
 [new Date(2010,7,18), 47.65, undefined, undefined, undefined ],
 [new Date(2010,7,19), 47.15, undefined, undefined, undefined ],
 [new Date(2010,7,20), 47.74, undefined, undefined, undefined ],
 [new Date(2010,7,23), 47.51, undefined, undefined, undefined ],
 [new Date(2010,7,24), 46.8, undefined, undefined, undefined ],
 [new Date(2010,7,25), 46.41, undefined, undefined, undefined ],
 [new Date(2010,7,26), 46.49, undefined, undefined, undefined ],
 [new Date(2010,7,27), 47.09, undefined, undefined, undefined ],
 [new Date(2010,7,30), 45.78, undefined, undefined, undefined ],
 [new Date(2010,7,31), 46.47, undefined, undefined, undefined ],
 [new Date(2010,8,1), 47.17, undefined, undefined, undefined ]
 ]); }