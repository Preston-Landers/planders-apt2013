
function addChartData(data) {
data.addRows([
 [new Date(2010,7,2), 74.87, undefined, undefined, undefined ],
 [new Date(2010,7,3), 75.04, undefined, undefined, undefined ],
 [new Date(2010,7,4), 75.65, undefined, undefined, undefined ],
 [new Date(2010,7,5), 75.74, undefined, undefined, undefined ],
 [new Date(2010,7,6), 75.5, undefined, undefined, undefined ],
 [new Date(2010,7,9), 75.41, undefined, undefined, undefined ],
 [new Date(2010,7,10), 76.54, undefined, undefined, undefined ],
 [new Date(2010,7,11), 74.94, undefined, undefined, undefined ],
 [new Date(2010,7,12), 75.42, undefined, undefined, undefined ],
 [new Date(2010,7,13), 75.01, undefined, undefined, undefined ],
 [new Date(2010,7,16), 74.86, undefined, undefined, undefined ],
 [new Date(2010,7,17), 76.07, undefined, undefined, undefined ],
 [new Date(2010,7,18), 76.0, undefined, undefined, undefined ],
 [new Date(2010,7,19), 74.95, undefined, undefined, undefined ],
 [new Date(2010,7,20), 75.76, undefined, undefined, undefined ],
 [new Date(2010,7,23), 75.61, undefined, undefined, undefined ],
 [new Date(2010,7,24), 75.53, undefined, undefined, undefined ],
 [new Date(2010,7,25), 76.12, undefined, undefined, undefined ],
 [new Date(2010,7,26), 75.08, undefined, undefined, undefined ],
 [new Date(2010,7,27), 75.22, undefined, undefined, undefined ],
 [new Date(2010,7,30), 73.97, undefined, undefined, undefined ],
 [new Date(2010,7,31), 72.62, undefined, undefined, undefined ],
 [new Date(2010,8,1), 74.0, undefined, undefined, undefined ]
 ]); }