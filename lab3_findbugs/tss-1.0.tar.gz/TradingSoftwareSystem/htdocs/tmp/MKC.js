
function addChartData(data) {
data.addRows([
 [new Date(2010,7,2), 39.71, undefined, undefined, undefined ],
 [new Date(2010,7,3), 39.82, undefined, undefined, undefined ],
 [new Date(2010,7,4), 40.3, undefined, undefined, undefined ],
 [new Date(2010,7,5), 39.62, undefined, undefined, undefined ],
 [new Date(2010,7,6), 39.32, undefined, undefined, undefined ],
 [new Date(2010,7,9), 39.59, undefined, undefined, undefined ],
 [new Date(2010,7,10), 39.83, undefined, undefined, undefined ],
 [new Date(2010,7,11), 39.52, undefined, undefined, undefined ],
 [new Date(2010,7,12), 39.86, undefined, undefined, undefined ],
 [new Date(2010,7,13), 39.75, undefined, undefined, undefined ],
 [new Date(2010,7,16), 39.68, undefined, undefined, undefined ],
 [new Date(2010,7,17), 40.28, undefined, undefined, undefined ],
 [new Date(2010,7,18), 40.64, undefined, undefined, undefined ],
 [new Date(2010,7,19), 40.56, undefined, undefined, undefined ],
 [new Date(2010,7,20), 40.9, undefined, undefined, undefined ],
 [new Date(2010,7,23), 40.53, undefined, undefined, undefined ],
 [new Date(2010,7,24), 39.63, undefined, undefined, undefined ],
 [new Date(2010,7,25), 39.59, undefined, undefined, undefined ],
 [new Date(2010,7,26), 39.56, undefined, undefined, undefined ],
 [new Date(2010,7,27), 40.1, undefined, undefined, undefined ],
 [new Date(2010,7,30), 39.76, undefined, undefined, undefined ],
 [new Date(2010,7,31), 39.87, undefined, undefined, undefined ],
 [new Date(2010,8,1), 40.36, undefined, undefined, undefined ]
 ]); }