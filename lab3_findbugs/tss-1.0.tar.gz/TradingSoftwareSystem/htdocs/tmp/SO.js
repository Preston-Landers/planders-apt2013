
function addChartData(data) {
data.addRows([
 [new Date(2010,7,2), 35.84, undefined, undefined, undefined ],
 [new Date(2010,7,3), 35.61, undefined, undefined, undefined ],
 [new Date(2010,7,4), 35.77, undefined, undefined, undefined ],
 [new Date(2010,7,5), 35.92, undefined, undefined, undefined ],
 [new Date(2010,7,6), 35.88, undefined, undefined, undefined ],
 [new Date(2010,7,9), 36.15, undefined, undefined, undefined ],
 [new Date(2010,7,10), 36.36, undefined, undefined, undefined ],
 [new Date(2010,7,11), 35.86, undefined, undefined, undefined ],
 [new Date(2010,7,12), 35.78, undefined, undefined, undefined ],
 [new Date(2010,7,13), 35.84, undefined, undefined, undefined ],
 [new Date(2010,7,16), 35.87, undefined, undefined, undefined ],
 [new Date(2010,7,17), 36.06, undefined, undefined, undefined ],
 [new Date(2010,7,18), 35.95, undefined, undefined, undefined ],
 [new Date(2010,7,19), 35.49, undefined, undefined, undefined ],
 [new Date(2010,7,20), 35.78, undefined, undefined, undefined ],
 [new Date(2010,7,23), 35.88, undefined, undefined, undefined ],
 [new Date(2010,7,24), 36.42, undefined, undefined, undefined ],
 [new Date(2010,7,25), 36.28, undefined, undefined, undefined ],
 [new Date(2010,7,26), 36.14, undefined, undefined, undefined ],
 [new Date(2010,7,27), 36.97, undefined, undefined, undefined ],
 [new Date(2010,7,30), 36.52, undefined, undefined, undefined ],
 [new Date(2010,7,31), 36.69, undefined, undefined, undefined ],
 [new Date(2010,8,1), 36.9, undefined, undefined, undefined ]
 ]); }