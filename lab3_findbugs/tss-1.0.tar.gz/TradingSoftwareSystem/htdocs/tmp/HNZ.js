
function addChartData(data) {
data.addRows([
 [new Date(2010,7,2), 44.95, undefined, undefined, undefined ],
 [new Date(2010,7,3), 45.3, undefined, undefined, undefined ],
 [new Date(2010,7,4), 45.88, undefined, undefined, undefined ],
 [new Date(2010,7,5), 45.43, undefined, undefined, undefined ],
 [new Date(2010,7,6), 45.34, undefined, undefined, undefined ],
 [new Date(2010,7,9), 45.65, undefined, undefined, undefined ],
 [new Date(2010,7,10), 45.7, undefined, undefined, undefined ],
 [new Date(2010,7,11), 45.3, undefined, undefined, undefined ],
 [new Date(2010,7,12), 45.3, undefined, undefined, undefined ],
 [new Date(2010,7,13), 45.64, undefined, undefined, undefined ],
 [new Date(2010,7,16), 45.63, undefined, undefined, undefined ],
 [new Date(2010,7,17), 46.48, undefined, undefined, undefined ],
 [new Date(2010,7,18), 47.0, undefined, undefined, undefined ],
 [new Date(2010,7,19), 46.56, undefined, undefined, undefined ],
 [new Date(2010,7,20), 47.1, undefined, undefined, undefined ],
 [new Date(2010,7,23), 46.88, undefined, undefined, undefined ],
 [new Date(2010,7,24), 46.38, undefined, undefined, undefined ],
 [new Date(2010,7,25), 46.39, undefined, undefined, undefined ],
 [new Date(2010,7,26), 46.2, undefined, undefined, undefined ],
 [new Date(2010,7,27), 46.85, undefined, undefined, undefined ],
 [new Date(2010,7,30), 46.09, undefined, undefined, undefined ],
 [new Date(2010,7,31), 46.24, undefined, undefined, undefined ],
 [new Date(2010,8,1), 46.27, undefined, undefined, undefined ]
 ]); }