
function addChartData(data) {
data.addRows([
 [new Date(2010,7,2), 57.78, undefined, undefined, undefined ],
 [new Date(2010,7,3), 57.46, undefined, undefined, undefined ],
 [new Date(2010,7,4), 57.52, undefined, undefined, undefined ],
 [new Date(2010,7,5), 57.38, undefined, undefined, undefined ],
 [new Date(2010,7,6), 57.77, undefined, undefined, undefined ],
 [new Date(2010,7,9), 57.3, undefined, undefined, undefined ],
 [new Date(2010,7,10), 57.39, undefined, undefined, undefined ],
 [new Date(2010,7,11), 56.53, undefined, undefined, undefined ],
 [new Date(2010,7,12), 56.57, undefined, undefined, undefined ],
 [new Date(2010,7,13), 56.37, undefined, undefined, undefined ],
 [new Date(2010,7,16), 56.66, undefined, undefined, undefined ],
 [new Date(2010,7,17), 57.53, undefined, undefined, undefined ],
 [new Date(2010,7,18), 57.81, undefined, undefined, undefined ],
 [new Date(2010,7,19), 56.76, undefined, undefined, undefined ],
 [new Date(2010,7,20), 56.64, undefined, undefined, undefined ],
 [new Date(2010,7,23), 56.46, undefined, undefined, undefined ],
 [new Date(2010,7,24), 56.49, undefined, undefined, undefined ],
 [new Date(2010,7,25), 56.65, undefined, undefined, undefined ],
 [new Date(2010,7,26), 55.76, undefined, undefined, undefined ],
 [new Date(2010,7,27), 55.26, undefined, undefined, undefined ],
 [new Date(2010,7,30), 54.96, undefined, undefined, undefined ],
 [new Date(2010,7,31), 54.54, undefined, undefined, undefined ],
 [new Date(2010,8,1), 55.74, undefined, undefined, undefined ]
 ]); }