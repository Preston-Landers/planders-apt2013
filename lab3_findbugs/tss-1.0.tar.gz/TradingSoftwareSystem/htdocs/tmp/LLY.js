
function addChartData(data) {
data.addRows([
 [new Date(2010,7,2), 36.34, undefined, undefined, undefined ],
 [new Date(2010,7,3), 36.58, undefined, undefined, undefined ],
 [new Date(2010,7,4), 36.78, undefined, undefined, undefined ],
 [new Date(2010,7,5), 36.85, undefined, undefined, undefined ],
 [new Date(2010,7,6), 36.87, undefined, undefined, undefined ],
 [new Date(2010,7,9), 36.96, undefined, undefined, undefined ],
 [new Date(2010,7,10), 37.77, undefined, undefined, undefined ],
 [new Date(2010,7,11), 36.71, undefined, undefined, undefined ],
 [new Date(2010,7,12), 36.6, undefined, undefined, undefined ],
 [new Date(2010,7,13), 35.7, undefined, undefined, undefined ],
 [new Date(2010,7,16), 35.57, undefined, undefined, undefined ],
 [new Date(2010,7,17), 34.75, undefined, undefined, undefined ],
 [new Date(2010,7,18), 34.78, undefined, undefined, undefined ],
 [new Date(2010,7,19), 34.28, undefined, undefined, undefined ],
 [new Date(2010,7,20), 34.17, undefined, undefined, undefined ],
 [new Date(2010,7,23), 34.31, undefined, undefined, undefined ],
 [new Date(2010,7,24), 33.97, undefined, undefined, undefined ],
 [new Date(2010,7,25), 34.31, undefined, undefined, undefined ],
 [new Date(2010,7,26), 33.95, undefined, undefined, undefined ],
 [new Date(2010,7,27), 34.2, undefined, undefined, undefined ],
 [new Date(2010,7,30), 33.97, undefined, undefined, undefined ],
 [new Date(2010,7,31), 33.59, undefined, undefined, undefined ],
 [new Date(2010,8,1), 34.2, undefined, undefined, undefined ]
 ]); }