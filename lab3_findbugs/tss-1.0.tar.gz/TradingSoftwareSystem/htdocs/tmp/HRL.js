
function addChartData(data) {
data.addRows([
 [new Date(2010,7,2), 43.22, undefined, undefined, undefined ],
 [new Date(2010,7,3), 43.05, undefined, undefined, undefined ],
 [new Date(2010,7,4), 43.27, undefined, undefined, undefined ],
 [new Date(2010,7,5), 42.99, undefined, undefined, undefined ],
 [new Date(2010,7,6), 42.86, undefined, undefined, undefined ],
 [new Date(2010,7,9), 43.18, undefined, undefined, undefined ],
 [new Date(2010,7,10), 43.58, undefined, undefined, undefined ],
 [new Date(2010,7,11), 42.76, undefined, undefined, undefined ],
 [new Date(2010,7,12), 42.69, undefined, undefined, undefined ],
 [new Date(2010,7,13), 42.9, undefined, undefined, undefined ],
 [new Date(2010,7,16), 42.93, undefined, undefined, undefined ],
 [new Date(2010,7,17), 43.44, undefined, undefined, undefined ],
 [new Date(2010,7,18), 43.61, undefined, undefined, undefined ],
 [new Date(2010,7,19), 43.37, undefined, undefined, undefined ],
 [new Date(2010,7,20), 43.48, undefined, undefined, undefined ],
 [new Date(2010,7,23), 43.7, undefined, undefined, undefined ],
 [new Date(2010,7,24), 43.36, undefined, undefined, undefined ],
 [new Date(2010,7,25), 42.79, undefined, undefined, undefined ],
 [new Date(2010,7,26), 43.05, undefined, undefined, undefined ],
 [new Date(2010,7,27), 43.12, undefined, undefined, undefined ],
 [new Date(2010,7,30), 42.7, undefined, undefined, undefined ],
 [new Date(2010,7,31), 43.15, undefined, undefined, undefined ],
 [new Date(2010,8,1), 43.6, undefined, undefined, undefined ]
 ]); }