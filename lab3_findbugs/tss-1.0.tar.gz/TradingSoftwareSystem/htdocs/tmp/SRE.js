
function addChartData(data) {
data.addRows([
 [new Date(2010,7,2), 50.45, undefined, undefined, undefined ],
 [new Date(2010,7,3), 51.36, undefined, undefined, undefined ],
 [new Date(2010,7,4), 51.45, undefined, undefined, undefined ],
 [new Date(2010,7,5), 51.82, undefined, undefined, undefined ],
 [new Date(2010,7,6), 51.8, undefined, undefined, undefined ],
 [new Date(2010,7,9), 51.94, undefined, undefined, undefined ],
 [new Date(2010,7,10), 52.43, undefined, undefined, undefined ],
 [new Date(2010,7,11), 51.76, undefined, undefined, undefined ],
 [new Date(2010,7,12), 51.28, undefined, undefined, undefined ],
 [new Date(2010,7,13), 51.15, undefined, undefined, undefined ],
 [new Date(2010,7,16), 51.24, undefined, undefined, undefined ],
 [new Date(2010,7,17), 51.4, undefined, undefined, undefined ],
 [new Date(2010,7,18), 51.3, undefined, undefined, undefined ],
 [new Date(2010,7,19), 50.6, undefined, undefined, undefined ],
 [new Date(2010,7,20), 50.54, undefined, undefined, undefined ],
 [new Date(2010,7,23), 51.0, undefined, undefined, undefined ],
 [new Date(2010,7,24), 51.1, undefined, undefined, undefined ],
 [new Date(2010,7,25), 51.25, undefined, undefined, undefined ],
 [new Date(2010,7,26), 51.33, undefined, undefined, undefined ],
 [new Date(2010,7,27), 51.97, undefined, undefined, undefined ],
 [new Date(2010,7,30), 51.01, undefined, undefined, undefined ],
 [new Date(2010,7,31), 50.92, undefined, undefined, undefined ],
 [new Date(2010,8,1), 52.49, undefined, undefined, undefined ]
 ]); }