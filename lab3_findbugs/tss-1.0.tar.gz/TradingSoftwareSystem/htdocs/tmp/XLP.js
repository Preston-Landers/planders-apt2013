
function addChartData(data) {
data.addRows([
 [new Date(2010,7,2), 27.29, undefined, undefined, undefined ],
 [new Date(2010,7,3), 27.05, undefined, undefined, undefined ],
 [new Date(2010,7,4), 27.15, undefined, undefined, undefined ],
 [new Date(2010,7,5), 27.03, undefined, undefined, undefined ],
 [new Date(2010,7,6), 27.09, undefined, undefined, undefined ],
 [new Date(2010,7,9), 27.23, undefined, undefined, undefined ],
 [new Date(2010,7,10), 27.29, undefined, undefined, undefined ],
 [new Date(2010,7,11), 26.84, undefined, undefined, undefined ],
 [new Date(2010,7,12), 26.81, undefined, undefined, undefined ],
 [new Date(2010,7,13), 26.8, undefined, undefined, undefined ],
 [new Date(2010,7,16), 26.77, undefined, undefined, undefined ],
 [new Date(2010,7,17), 27.03, undefined, undefined, undefined ],
 [new Date(2010,7,18), 27.05, undefined, undefined, undefined ],
 [new Date(2010,7,19), 26.73, undefined, undefined, undefined ],
 [new Date(2010,7,20), 26.73, undefined, undefined, undefined ],
 [new Date(2010,7,23), 26.79, undefined, undefined, undefined ],
 [new Date(2010,7,24), 26.66, undefined, undefined, undefined ],
 [new Date(2010,7,25), 26.72, undefined, undefined, undefined ],
 [new Date(2010,7,26), 26.52, undefined, undefined, undefined ],
 [new Date(2010,7,27), 26.69, undefined, undefined, undefined ],
 [new Date(2010,7,30), 26.46, undefined, undefined, undefined ],
 [new Date(2010,7,31), 26.48, undefined, undefined, undefined ],
 [new Date(2010,8,1), 26.95, undefined, undefined, undefined ]
 ]); }