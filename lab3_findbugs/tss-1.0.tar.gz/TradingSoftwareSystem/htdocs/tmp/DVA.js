
function addChartData(data) {
data.addRows([
 [new Date(2010,7,2), 57.89, undefined, undefined, undefined ],
 [new Date(2010,7,3), 61.1, undefined, undefined, undefined ],
 [new Date(2010,7,4), 61.61, undefined, undefined, undefined ],
 [new Date(2010,7,5), 63.19, undefined, undefined, undefined ],
 [new Date(2010,7,6), 63.62, undefined, undefined, undefined ],
 [new Date(2010,7,9), 63.61, undefined, undefined, undefined ],
 [new Date(2010,7,10), 63.65, undefined, undefined, undefined ],
 [new Date(2010,7,11), 63.05, undefined, undefined, undefined ],
 [new Date(2010,7,12), 63.79, undefined, undefined, undefined ],
 [new Date(2010,7,13), 64.08, undefined, undefined, undefined ],
 [new Date(2010,7,16), 64.3, undefined, undefined, undefined ],
 [new Date(2010,7,17), 64.76, undefined, undefined, undefined ],
 [new Date(2010,7,18), 64.63, undefined, undefined, undefined ],
 [new Date(2010,7,19), 63.67, undefined, undefined, undefined ],
 [new Date(2010,7,20), 63.82, undefined, undefined, undefined ],
 [new Date(2010,7,23), 64.15, undefined, undefined, undefined ],
 [new Date(2010,7,24), 64.2, undefined, undefined, undefined ],
 [new Date(2010,7,25), 64.76, undefined, undefined, undefined ],
 [new Date(2010,7,26), 64.1, undefined, undefined, undefined ],
 [new Date(2010,7,27), 65.44, undefined, undefined, undefined ],
 [new Date(2010,7,30), 65.24, undefined, undefined, undefined ],
 [new Date(2010,7,31), 64.62, undefined, undefined, undefined ],
 [new Date(2010,8,1), 63.88, undefined, undefined, undefined ]
 ]); }