
function addChartData(data) {
data.addRows([
 [new Date(2010,7,2), 63.5, undefined, undefined, undefined ],
 [new Date(2010,7,3), 62.1, undefined, undefined, undefined ],
 [new Date(2010,7,4), 62.97, undefined, undefined, undefined ],
 [new Date(2010,7,5), 62.84, undefined, undefined, undefined ],
 [new Date(2010,7,6), 62.81, undefined, undefined, undefined ],
 [new Date(2010,7,9), 62.31, undefined, undefined, undefined ],
 [new Date(2010,7,10), 61.61, undefined, undefined, undefined ],
 [new Date(2010,7,11), 60.6, undefined, undefined, undefined ],
 [new Date(2010,7,12), 60.95, undefined, undefined, undefined ],
 [new Date(2010,7,13), 60.65, undefined, undefined, undefined ],
 [new Date(2010,7,16), 60.85, undefined, undefined, undefined ],
 [new Date(2010,7,17), 61.6, undefined, undefined, undefined ],
 [new Date(2010,7,18), 62.27, undefined, undefined, undefined ],
 [new Date(2010,7,19), 61.45, undefined, undefined, undefined ],
 [new Date(2010,7,20), 61.67, undefined, undefined, undefined ],
 [new Date(2010,7,23), 61.31, undefined, undefined, undefined ],
 [new Date(2010,7,24), 60.32, undefined, undefined, undefined ],
 [new Date(2010,7,25), 60.46, undefined, undefined, undefined ],
 [new Date(2010,7,26), 59.77, undefined, undefined, undefined ],
 [new Date(2010,7,27), 60.36, undefined, undefined, undefined ],
 [new Date(2010,7,30), 59.05, undefined, undefined, undefined ],
 [new Date(2010,7,31), 58.05, undefined, undefined, undefined ],
 [new Date(2010,8,1), 58.79, undefined, undefined, undefined ]
 ]); }