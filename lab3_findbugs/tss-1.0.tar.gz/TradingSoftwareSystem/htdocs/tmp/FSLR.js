
function addChartData(data) {
data.addRows([
 [new Date(2010,7,2), 126.14, undefined, undefined, undefined ],
 [new Date(2010,7,3), 126.7, undefined, undefined, undefined ],
 [new Date(2010,7,4), 131.45, undefined, undefined, undefined ],
 [new Date(2010,7,5), 129.73, undefined, undefined, undefined ],
 [new Date(2010,7,6), 129.34, undefined, undefined, undefined ],
 [new Date(2010,7,9), 129.95, undefined, undefined, undefined ],
 [new Date(2010,7,10), 129.22, undefined, undefined, undefined ],
 [new Date(2010,7,11), 125.44, undefined, undefined, undefined ],
 [new Date(2010,7,12), 124.65, undefined, undefined, undefined ],
 [new Date(2010,7,13), 124.52, undefined, undefined, undefined ],
 [new Date(2010,7,16), 125.05, undefined, undefined, undefined ],
 [new Date(2010,7,17), 125.86, undefined, undefined, undefined ],
 [new Date(2010,7,18), 125.08, undefined, undefined, undefined ],
 [new Date(2010,7,19), 123.21, undefined, undefined, undefined ],
 [new Date(2010,7,20), 125.03, undefined, undefined, undefined ],
 [new Date(2010,7,23), 126.29, undefined, undefined, undefined ],
 [new Date(2010,7,24), 125.16, undefined, undefined, undefined ],
 [new Date(2010,7,25), 124.98, undefined, undefined, undefined ],
 [new Date(2010,7,26), 126.68, undefined, undefined, undefined ],
 [new Date(2010,7,27), 128.88, undefined, undefined, undefined ],
 [new Date(2010,7,30), 126.28, undefined, undefined, undefined ],
 [new Date(2010,7,31), 127.85, undefined, undefined, undefined ],
 [new Date(2010,8,1), 130.17, undefined, undefined, undefined ]
 ]); }