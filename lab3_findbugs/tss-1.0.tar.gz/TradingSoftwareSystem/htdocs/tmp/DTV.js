
function addChartData(data) {
data.addRows([
 [new Date(2010,7,2), 37.62, undefined, undefined, undefined ],
 [new Date(2010,7,3), 37.24, undefined, undefined, undefined ],
 [new Date(2010,7,4), 37.9, undefined, undefined, undefined ],
 [new Date(2010,7,5), 38.8, undefined, undefined, undefined ],
 [new Date(2010,7,6), 38.61, undefined, undefined, undefined ],
 [new Date(2010,7,9), 38.97, undefined, undefined, undefined ],
 [new Date(2010,7,10), 39.43, undefined, undefined, undefined ],
 [new Date(2010,7,11), 38.8, undefined, undefined, undefined ],
 [new Date(2010,7,12), 38.75, undefined, undefined, undefined ],
 [new Date(2010,7,13), 38.56, undefined, undefined, undefined ],
 [new Date(2010,7,16), 38.54, undefined, undefined, undefined ],
 [new Date(2010,7,17), 38.79, undefined, undefined, undefined ],
 [new Date(2010,7,18), 38.45, undefined, undefined, undefined ],
 [new Date(2010,7,19), 38.05, undefined, undefined, undefined ],
 [new Date(2010,7,20), 38.05, undefined, undefined, undefined ],
 [new Date(2010,7,23), 37.81, undefined, undefined, undefined ],
 [new Date(2010,7,24), 37.42, undefined, undefined, undefined ],
 [new Date(2010,7,25), 37.64, undefined, undefined, undefined ],
 [new Date(2010,7,26), 37.77, undefined, undefined, undefined ],
 [new Date(2010,7,27), 38.17, undefined, undefined, undefined ],
 [new Date(2010,7,30), 37.8, undefined, undefined, undefined ],
 [new Date(2010,7,31), 37.9, undefined, undefined, undefined ],
 [new Date(2010,8,1), 38.1, undefined, undefined, undefined ]
 ]); }