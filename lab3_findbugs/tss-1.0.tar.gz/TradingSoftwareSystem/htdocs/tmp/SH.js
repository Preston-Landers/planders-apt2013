
function addChartData(data) {
data.addRows([
 [new Date(2010,7,2), 49.99, undefined, undefined, undefined ],
 [new Date(2010,7,3), 50.23, undefined, undefined, undefined ],
 [new Date(2010,7,4), 49.9, undefined, undefined, undefined ],
 [new Date(2010,7,5), 50.0, undefined, undefined, undefined ],
 [new Date(2010,7,6), 50.16, undefined, undefined, undefined ],
 [new Date(2010,7,9), 49.89, undefined, undefined, undefined ],
 [new Date(2010,7,10), 50.17, undefined, undefined, undefined ],
 [new Date(2010,7,11), 51.54, undefined, undefined, undefined ],
 [new Date(2010,7,12), 51.88, undefined, undefined, undefined ],
 [new Date(2010,7,13), 52.04, undefined, undefined, undefined ],
 [new Date(2010,7,16), 52.05, undefined, undefined, undefined ],
 [new Date(2010,7,17), 51.41, undefined, undefined, undefined ],
 [new Date(2010,7,18), 51.31, undefined, undefined, undefined ],
 [new Date(2010,7,19), 52.22, undefined, undefined, undefined ],
 [new Date(2010,7,20), 52.39, undefined, undefined, undefined ],
 [new Date(2010,7,23), 52.57, undefined, undefined, undefined ],
 [new Date(2010,7,24), 53.33, undefined, undefined, undefined ],
 [new Date(2010,7,25), 53.15, undefined, undefined, undefined ],
 [new Date(2010,7,26), 53.51, undefined, undefined, undefined ],
 [new Date(2010,7,27), 52.67, undefined, undefined, undefined ],
 [new Date(2010,7,30), 53.41, undefined, undefined, undefined ],
 [new Date(2010,7,31), 53.43, undefined, undefined, undefined ],
 [new Date(2010,8,1), 51.83, undefined, undefined, undefined ]
 ]); }