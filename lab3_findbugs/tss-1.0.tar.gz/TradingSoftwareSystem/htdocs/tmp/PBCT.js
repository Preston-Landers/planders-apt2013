
function addChartData(data) {
data.addRows([
 [new Date(2010,7,2), 13.9, undefined, undefined, undefined ],
 [new Date(2010,7,3), 13.75, undefined, undefined, undefined ],
 [new Date(2010,7,4), 13.67, undefined, undefined, undefined ],
 [new Date(2010,7,5), 13.68, undefined, undefined, undefined ],
 [new Date(2010,7,6), 13.57, undefined, undefined, undefined ],
 [new Date(2010,7,9), 13.68, undefined, undefined, undefined ],
 [new Date(2010,7,10), 13.75, undefined, undefined, undefined ],
 [new Date(2010,7,11), 13.4, undefined, undefined, undefined ],
 [new Date(2010,7,12), 13.25, undefined, undefined, undefined ],
 [new Date(2010,7,13), 13.22, undefined, undefined, undefined ],
 [new Date(2010,7,16), 13.36, undefined, undefined, undefined ],
 [new Date(2010,7,17), 13.48, undefined, undefined, undefined ],
 [new Date(2010,7,18), 13.43, undefined, undefined, undefined ],
 [new Date(2010,7,19), 13.13, undefined, undefined, undefined ],
 [new Date(2010,7,20), 13.24, undefined, undefined, undefined ],
 [new Date(2010,7,23), 13.14, undefined, undefined, undefined ],
 [new Date(2010,7,24), 12.84, undefined, undefined, undefined ],
 [new Date(2010,7,25), 12.78, undefined, undefined, undefined ],
 [new Date(2010,7,26), 12.67, undefined, undefined, undefined ],
 [new Date(2010,7,27), 12.79, undefined, undefined, undefined ],
 [new Date(2010,7,30), 12.63, undefined, undefined, undefined ],
 [new Date(2010,7,31), 12.7, undefined, undefined, undefined ],
 [new Date(2010,8,1), 12.73, undefined, undefined, undefined ]
 ]); }