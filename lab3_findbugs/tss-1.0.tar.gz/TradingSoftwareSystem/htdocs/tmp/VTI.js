
function addChartData(data) {
data.addRows([
 [new Date(2010,7,2), 57.46, undefined, undefined, undefined ],
 [new Date(2010,7,3), 57.15, undefined, undefined, undefined ],
 [new Date(2010,7,4), 57.6, undefined, undefined, undefined ],
 [new Date(2010,7,5), 57.48, undefined, undefined, undefined ],
 [new Date(2010,7,6), 57.27, undefined, undefined, undefined ],
 [new Date(2010,7,9), 57.57, undefined, undefined, undefined ],
 [new Date(2010,7,10), 57.21, undefined, undefined, undefined ],
 [new Date(2010,7,11), 55.52, undefined, undefined, undefined ],
 [new Date(2010,7,12), 55.21, undefined, undefined, undefined ],
 [new Date(2010,7,13), 55.0, undefined, undefined, undefined ],
 [new Date(2010,7,16), 54.95, undefined, undefined, undefined ],
 [new Date(2010,7,17), 55.73, undefined, undefined, undefined ],
 [new Date(2010,7,18), 55.86, undefined, undefined, undefined ],
 [new Date(2010,7,19), 54.88, undefined, undefined, undefined ],
 [new Date(2010,7,20), 54.69, undefined, undefined, undefined ],
 [new Date(2010,7,23), 54.4, undefined, undefined, undefined ],
 [new Date(2010,7,24), 53.62, undefined, undefined, undefined ],
 [new Date(2010,7,25), 53.79, undefined, undefined, undefined ],
 [new Date(2010,7,26), 53.46, undefined, undefined, undefined ],
 [new Date(2010,7,27), 54.38, undefined, undefined, undefined ],
 [new Date(2010,7,30), 53.59, undefined, undefined, undefined ],
 [new Date(2010,7,31), 53.6, undefined, undefined, undefined ],
 [new Date(2010,8,1), 55.17, undefined, undefined, undefined ]
 ]); }