
function addChartData(data) {
data.addRows([
 [new Date(2010,7,2), 29.56, undefined, undefined, undefined ],
 [new Date(2010,7,3), 29.54, undefined, undefined, undefined ],
 [new Date(2010,7,4), 29.4, undefined, undefined, undefined ],
 [new Date(2010,7,5), 29.55, undefined, undefined, undefined ],
 [new Date(2010,7,6), 29.55, undefined, undefined, undefined ],
 [new Date(2010,7,9), 29.86, undefined, undefined, undefined ],
 [new Date(2010,7,10), 30.02, undefined, undefined, undefined ],
 [new Date(2010,7,11), 29.56, undefined, undefined, undefined ],
 [new Date(2010,7,12), 30.32, undefined, undefined, undefined ],
 [new Date(2010,7,13), 30.03, undefined, undefined, undefined ],
 [new Date(2010,7,16), 29.96, undefined, undefined, undefined ],
 [new Date(2010,7,17), 30.17, undefined, undefined, undefined ],
 [new Date(2010,7,18), 30.15, undefined, undefined, undefined ],
 [new Date(2010,7,19), 29.62, undefined, undefined, undefined ],
 [new Date(2010,7,20), 29.37, undefined, undefined, undefined ],
 [new Date(2010,7,23), 29.41, undefined, undefined, undefined ],
 [new Date(2010,7,24), 29.47, undefined, undefined, undefined ],
 [new Date(2010,7,25), 29.66, undefined, undefined, undefined ],
 [new Date(2010,7,26), 29.5, undefined, undefined, undefined ],
 [new Date(2010,7,27), 29.84, undefined, undefined, undefined ],
 [new Date(2010,7,30), 29.44, undefined, undefined, undefined ],
 [new Date(2010,7,31), 29.53, undefined, undefined, undefined ],
 [new Date(2010,8,1), 30.26, undefined, undefined, undefined ]
 ]); }