
function addChartData(data) {
data.addRows([
 [new Date(2010,7,2), 80.23, undefined, undefined, undefined ],
 [new Date(2010,7,3), 80.55, undefined, undefined, undefined ],
 [new Date(2010,7,4), 81.15, undefined, undefined, undefined ],
 [new Date(2010,7,5), 80.93, undefined, undefined, undefined ],
 [new Date(2010,7,6), 80.7, undefined, undefined, undefined ],
 [new Date(2010,7,9), 80.8, undefined, undefined, undefined ],
 [new Date(2010,7,10), 81.01, undefined, undefined, undefined ],
 [new Date(2010,7,11), 79.4, undefined, undefined, undefined ],
 [new Date(2010,7,12), 79.65, undefined, undefined, undefined ],
 [new Date(2010,7,13), 79.92, undefined, undefined, undefined ],
 [new Date(2010,7,16), 79.44, undefined, undefined, undefined ],
 [new Date(2010,7,17), 80.77, undefined, undefined, undefined ],
 [new Date(2010,7,18), 80.77, undefined, undefined, undefined ],
 [new Date(2010,7,19), 79.22, undefined, undefined, undefined ],
 [new Date(2010,7,20), 78.82, undefined, undefined, undefined ],
 [new Date(2010,7,23), 78.43, undefined, undefined, undefined ],
 [new Date(2010,7,24), 76.58, undefined, undefined, undefined ],
 [new Date(2010,7,25), 77.04, undefined, undefined, undefined ],
 [new Date(2010,7,26), 76.54, undefined, undefined, undefined ],
 [new Date(2010,7,27), 77.98, undefined, undefined, undefined ],
 [new Date(2010,7,30), 77.18, undefined, undefined, undefined ],
 [new Date(2010,7,31), 76.83, undefined, undefined, undefined ],
 [new Date(2010,8,1), 77.97, undefined, undefined, undefined ]
 ]); }