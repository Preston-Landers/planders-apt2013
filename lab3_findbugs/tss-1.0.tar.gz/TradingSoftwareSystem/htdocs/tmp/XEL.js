
function addChartData(data) {
data.addRows([
 [new Date(2010,7,2), 22.34, undefined, undefined, undefined ],
 [new Date(2010,7,3), 22.1, undefined, undefined, undefined ],
 [new Date(2010,7,4), 21.86, undefined, undefined, undefined ],
 [new Date(2010,7,5), 22.06, undefined, undefined, undefined ],
 [new Date(2010,7,6), 22.12, undefined, undefined, undefined ],
 [new Date(2010,7,9), 22.27, undefined, undefined, undefined ],
 [new Date(2010,7,10), 22.41, undefined, undefined, undefined ],
 [new Date(2010,7,11), 22.15, undefined, undefined, undefined ],
 [new Date(2010,7,12), 22.28, undefined, undefined, undefined ],
 [new Date(2010,7,13), 22.42, undefined, undefined, undefined ],
 [new Date(2010,7,16), 22.19, undefined, undefined, undefined ],
 [new Date(2010,7,17), 22.35, undefined, undefined, undefined ],
 [new Date(2010,7,18), 22.16, undefined, undefined, undefined ],
 [new Date(2010,7,19), 21.75, undefined, undefined, undefined ],
 [new Date(2010,7,20), 21.87, undefined, undefined, undefined ],
 [new Date(2010,7,23), 21.96, undefined, undefined, undefined ],
 [new Date(2010,7,24), 22.1, undefined, undefined, undefined ],
 [new Date(2010,7,25), 22.19, undefined, undefined, undefined ],
 [new Date(2010,7,26), 22.18, undefined, undefined, undefined ],
 [new Date(2010,7,27), 22.57, undefined, undefined, undefined ],
 [new Date(2010,7,30), 22.23, undefined, undefined, undefined ],
 [new Date(2010,7,31), 22.31, undefined, undefined, undefined ],
 [new Date(2010,8,1), 22.8, undefined, undefined, undefined ]
 ]); }