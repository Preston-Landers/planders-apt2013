
function addChartData(data) {
data.addRows([
 [new Date(2010,7,2), 30.55, undefined, undefined, undefined ],
 [new Date(2010,7,3), 30.09, undefined, undefined, undefined ],
 [new Date(2010,7,4), 30.44, undefined, undefined, undefined ],
 [new Date(2010,7,5), 30.83, undefined, undefined, undefined ],
 [new Date(2010,7,6), 30.83, undefined, undefined, undefined ],
 [new Date(2010,7,9), 30.69, undefined, undefined, undefined ],
 [new Date(2010,7,10), 30.82, undefined, undefined, undefined ],
 [new Date(2010,7,11), 30.45, undefined, undefined, undefined ],
 [new Date(2010,7,12), 31.14, undefined, undefined, undefined ],
 [new Date(2010,7,13), 31.18, undefined, undefined, undefined ],
 [new Date(2010,7,16), 30.92, undefined, undefined, undefined ],
 [new Date(2010,7,17), 32.58, undefined, undefined, undefined ],
 [new Date(2010,7,18), 32.5, undefined, undefined, undefined ],
 [new Date(2010,7,19), 32.55, undefined, undefined, undefined ],
 [new Date(2010,7,20), 32.36, undefined, undefined, undefined ],
 [new Date(2010,7,23), 32.38, undefined, undefined, undefined ],
 [new Date(2010,7,24), 32.28, undefined, undefined, undefined ],
 [new Date(2010,7,25), 32.12, undefined, undefined, undefined ],
 [new Date(2010,7,26), 32.18, undefined, undefined, undefined ],
 [new Date(2010,7,27), 32.3, undefined, undefined, undefined ],
 [new Date(2010,7,30), 32.17, undefined, undefined, undefined ],
 [new Date(2010,7,31), 32.08, undefined, undefined, undefined ],
 [new Date(2010,8,1), 32.1, undefined, undefined, undefined ]
 ]); }