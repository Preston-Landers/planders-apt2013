
function addChartData(data) {
data.addRows([
 [new Date(2010,7,2), 54.87, undefined, undefined, undefined ],
 [new Date(2010,7,3), 54.71, undefined, undefined, undefined ],
 [new Date(2010,7,4), 55.76, undefined, undefined, undefined ],
 [new Date(2010,7,5), 55.32, undefined, undefined, undefined ],
 [new Date(2010,7,6), 55.94, undefined, undefined, undefined ],
 [new Date(2010,7,9), 55.66, undefined, undefined, undefined ],
 [new Date(2010,7,10), 55.72, undefined, undefined, undefined ],
 [new Date(2010,7,11), 53.69, undefined, undefined, undefined ],
 [new Date(2010,7,12), 54.75, undefined, undefined, undefined ],
 [new Date(2010,7,13), 55.02, undefined, undefined, undefined ],
 [new Date(2010,7,16), 54.08, undefined, undefined, undefined ],
 [new Date(2010,7,17), 53.96, undefined, undefined, undefined ],
 [new Date(2010,7,18), 54.14, undefined, undefined, undefined ],
 [new Date(2010,7,19), 52.72, undefined, undefined, undefined ],
 [new Date(2010,7,20), 52.34, undefined, undefined, undefined ],
 [new Date(2010,7,23), 51.95, undefined, undefined, undefined ],
 [new Date(2010,7,24), 51.06, undefined, undefined, undefined ],
 [new Date(2010,7,25), 51.84, undefined, undefined, undefined ],
 [new Date(2010,7,26), 50.93, undefined, undefined, undefined ],
 [new Date(2010,7,27), 52.08, undefined, undefined, undefined ],
 [new Date(2010,7,30), 51.63, undefined, undefined, undefined ],
 [new Date(2010,7,31), 51.04, undefined, undefined, undefined ],
 [new Date(2010,8,1), 52.59, undefined, undefined, undefined ]
 ]); }