
function addChartData(data) {
data.addRows([
 [new Date(2010,7,2), 37.99, undefined, undefined, undefined ],
 [new Date(2010,7,3), 37.86, undefined, undefined, undefined ],
 [new Date(2010,7,4), 38.27, undefined, undefined, undefined ],
 [new Date(2010,7,5), 38.81, undefined, undefined, undefined ],
 [new Date(2010,7,6), 38.38, undefined, undefined, undefined ],
 [new Date(2010,7,9), 38.9, undefined, undefined, undefined ],
 [new Date(2010,7,10), 38.43, undefined, undefined, undefined ],
 [new Date(2010,7,11), 37.24, undefined, undefined, undefined ],
 [new Date(2010,7,12), 36.74, undefined, undefined, undefined ],
 [new Date(2010,7,13), 36.36, undefined, undefined, undefined ],
 [new Date(2010,7,16), 36.25, undefined, undefined, undefined ],
 [new Date(2010,7,17), 36.64, undefined, undefined, undefined ],
 [new Date(2010,7,18), 36.94, undefined, undefined, undefined ],
 [new Date(2010,7,19), 36.39, undefined, undefined, undefined ],
 [new Date(2010,7,20), 36.45, undefined, undefined, undefined ],
 [new Date(2010,7,23), 35.78, undefined, undefined, undefined ],
 [new Date(2010,7,24), 35.33, undefined, undefined, undefined ],
 [new Date(2010,7,25), 35.45, undefined, undefined, undefined ],
 [new Date(2010,7,26), 35.31, undefined, undefined, undefined ],
 [new Date(2010,7,27), 35.69, undefined, undefined, undefined ],
 [new Date(2010,7,30), 35.11, undefined, undefined, undefined ],
 [new Date(2010,7,31), 35.01, undefined, undefined, undefined ],
 [new Date(2010,8,1), 35.81, undefined, undefined, undefined ]
 ]); }