
function addChartData(data) {
data.addRows([
 [new Date(2010,7,2), 36.05, undefined, undefined, undefined ],
 [new Date(2010,7,3), 35.9, undefined, undefined, undefined ],
 [new Date(2010,7,4), 36.39, undefined, undefined, undefined ],
 [new Date(2010,7,5), 36.29, undefined, undefined, undefined ],
 [new Date(2010,7,6), 36.18, undefined, undefined, undefined ],
 [new Date(2010,7,9), 36.21, undefined, undefined, undefined ],
 [new Date(2010,7,10), 36.42, undefined, undefined, undefined ],
 [new Date(2010,7,11), 36.1, undefined, undefined, undefined ],
 [new Date(2010,7,12), 36.08, undefined, undefined, undefined ],
 [new Date(2010,7,13), 36.19, undefined, undefined, undefined ],
 [new Date(2010,7,16), 36.27, undefined, undefined, undefined ],
 [new Date(2010,7,17), 36.88, undefined, undefined, undefined ],
 [new Date(2010,7,18), 36.91, undefined, undefined, undefined ],
 [new Date(2010,7,19), 36.51, undefined, undefined, undefined ],
 [new Date(2010,7,20), 36.64, undefined, undefined, undefined ],
 [new Date(2010,7,23), 36.9, undefined, undefined, undefined ],
 [new Date(2010,7,24), 36.91, undefined, undefined, undefined ],
 [new Date(2010,7,25), 37.25, undefined, undefined, undefined ],
 [new Date(2010,7,26), 36.95, undefined, undefined, undefined ],
 [new Date(2010,7,27), 37.47, undefined, undefined, undefined ],
 [new Date(2010,7,30), 36.98, undefined, undefined, undefined ],
 [new Date(2010,7,31), 37.26, undefined, undefined, undefined ],
 [new Date(2010,8,1), 36.97, undefined, undefined, undefined ]
 ]); }