
function addChartData(data) {
data.addRows([
 [new Date(2010,7,2), 55.72, undefined, undefined, undefined ],
 [new Date(2010,7,3), 55.7, undefined, undefined, undefined ],
 [new Date(2010,7,4), 56.13, undefined, undefined, undefined ],
 [new Date(2010,7,5), 56.31, undefined, undefined, undefined ],
 [new Date(2010,7,6), 55.64, undefined, undefined, undefined ],
 [new Date(2010,7,9), 55.87, undefined, undefined, undefined ],
 [new Date(2010,7,10), 55.41, undefined, undefined, undefined ],
 [new Date(2010,7,11), 53.76, undefined, undefined, undefined ],
 [new Date(2010,7,12), 53.44, undefined, undefined, undefined ],
 [new Date(2010,7,13), 53.35, undefined, undefined, undefined ],
 [new Date(2010,7,16), 53.34, undefined, undefined, undefined ],
 [new Date(2010,7,17), 54.23, undefined, undefined, undefined ],
 [new Date(2010,7,18), 53.71, undefined, undefined, undefined ],
 [new Date(2010,7,19), 52.84, undefined, undefined, undefined ],
 [new Date(2010,7,20), 52.19, undefined, undefined, undefined ],
 [new Date(2010,7,23), 52.21, undefined, undefined, undefined ],
 [new Date(2010,7,24), 51.4, undefined, undefined, undefined ],
 [new Date(2010,7,25), 51.24, undefined, undefined, undefined ],
 [new Date(2010,7,26), 50.78, undefined, undefined, undefined ],
 [new Date(2010,7,27), 52.1, undefined, undefined, undefined ],
 [new Date(2010,7,30), 51.34, undefined, undefined, undefined ],
 [new Date(2010,7,31), 51.2, undefined, undefined, undefined ],
 [new Date(2010,8,1), 53.11, undefined, undefined, undefined ]
 ]); }