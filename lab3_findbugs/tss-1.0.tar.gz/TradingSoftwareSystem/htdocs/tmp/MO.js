
function addChartData(data) {
data.addRows([
 [new Date(2010,7,2), 22.25, undefined, undefined, undefined ],
 [new Date(2010,7,3), 22.12, undefined, undefined, undefined ],
 [new Date(2010,7,4), 22.35, undefined, undefined, undefined ],
 [new Date(2010,7,5), 22.34, undefined, undefined, undefined ],
 [new Date(2010,7,6), 22.54, undefined, undefined, undefined ],
 [new Date(2010,7,9), 22.59, undefined, undefined, undefined ],
 [new Date(2010,7,10), 22.63, undefined, undefined, undefined ],
 [new Date(2010,7,11), 22.44, undefined, undefined, undefined ],
 [new Date(2010,7,12), 22.45, undefined, undefined, undefined ],
 [new Date(2010,7,13), 22.35, undefined, undefined, undefined ],
 [new Date(2010,7,16), 22.6, undefined, undefined, undefined ],
 [new Date(2010,7,17), 22.92, undefined, undefined, undefined ],
 [new Date(2010,7,18), 22.93, undefined, undefined, undefined ],
 [new Date(2010,7,19), 22.76, undefined, undefined, undefined ],
 [new Date(2010,7,20), 22.71, undefined, undefined, undefined ],
 [new Date(2010,7,23), 22.73, undefined, undefined, undefined ],
 [new Date(2010,7,24), 22.79, undefined, undefined, undefined ],
 [new Date(2010,7,25), 22.85, undefined, undefined, undefined ],
 [new Date(2010,7,26), 22.61, undefined, undefined, undefined ],
 [new Date(2010,7,27), 22.54, undefined, undefined, undefined ],
 [new Date(2010,7,30), 22.52, undefined, undefined, undefined ],
 [new Date(2010,7,31), 22.32, undefined, undefined, undefined ],
 [new Date(2010,8,1), 22.66, undefined, undefined, undefined ]
 ]); }