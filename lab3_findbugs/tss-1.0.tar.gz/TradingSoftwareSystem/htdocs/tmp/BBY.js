
function addChartData(data) {
data.addRows([
 [new Date(2010,7,2), 35.84, undefined, undefined, undefined ],
 [new Date(2010,7,3), 34.9, undefined, undefined, undefined ],
 [new Date(2010,7,4), 35.16, undefined, undefined, undefined ],
 [new Date(2010,7,5), 35.13, undefined, undefined, undefined ],
 [new Date(2010,7,6), 34.91, undefined, undefined, undefined ],
 [new Date(2010,7,9), 35.58, undefined, undefined, undefined ],
 [new Date(2010,7,10), 34.57, undefined, undefined, undefined ],
 [new Date(2010,7,11), 33.29, undefined, undefined, undefined ],
 [new Date(2010,7,12), 33.43, undefined, undefined, undefined ],
 [new Date(2010,7,13), 33.14, undefined, undefined, undefined ],
 [new Date(2010,7,16), 33.05, undefined, undefined, undefined ],
 [new Date(2010,7,17), 32.9, undefined, undefined, undefined ],
 [new Date(2010,7,18), 33.18, undefined, undefined, undefined ],
 [new Date(2010,7,19), 32.66, undefined, undefined, undefined ],
 [new Date(2010,7,20), 32.5, undefined, undefined, undefined ],
 [new Date(2010,7,23), 32.22, undefined, undefined, undefined ],
 [new Date(2010,7,24), 31.68, undefined, undefined, undefined ],
 [new Date(2010,7,25), 32.48, undefined, undefined, undefined ],
 [new Date(2010,7,26), 31.93, undefined, undefined, undefined ],
 [new Date(2010,7,27), 31.86, undefined, undefined, undefined ],
 [new Date(2010,7,30), 31.46, undefined, undefined, undefined ],
 [new Date(2010,7,31), 31.39, undefined, undefined, undefined ],
 [new Date(2010,8,1), 32.66, undefined, undefined, undefined ]
 ]); }