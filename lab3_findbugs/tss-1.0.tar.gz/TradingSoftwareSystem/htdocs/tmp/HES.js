
function addChartData(data) {
data.addRows([
 [new Date(2010,7,2), 55.94, undefined, undefined, undefined ],
 [new Date(2010,7,3), 56.08, undefined, undefined, undefined ],
 [new Date(2010,7,4), 56.5, undefined, undefined, undefined ],
 [new Date(2010,7,5), 56.31, undefined, undefined, undefined ],
 [new Date(2010,7,6), 55.59, undefined, undefined, undefined ],
 [new Date(2010,7,9), 56.06, undefined, undefined, undefined ],
 [new Date(2010,7,10), 55.56, undefined, undefined, undefined ],
 [new Date(2010,7,11), 53.4, undefined, undefined, undefined ],
 [new Date(2010,7,12), 53.16, undefined, undefined, undefined ],
 [new Date(2010,7,13), 52.77, undefined, undefined, undefined ],
 [new Date(2010,7,16), 52.62, undefined, undefined, undefined ],
 [new Date(2010,7,17), 53.44, undefined, undefined, undefined ],
 [new Date(2010,7,18), 52.9, undefined, undefined, undefined ],
 [new Date(2010,7,19), 51.99, undefined, undefined, undefined ],
 [new Date(2010,7,20), 51.24, undefined, undefined, undefined ],
 [new Date(2010,7,23), 51.23, undefined, undefined, undefined ],
 [new Date(2010,7,24), 50.21, undefined, undefined, undefined ],
 [new Date(2010,7,25), 50.41, undefined, undefined, undefined ],
 [new Date(2010,7,26), 49.88, undefined, undefined, undefined ],
 [new Date(2010,7,27), 51.46, undefined, undefined, undefined ],
 [new Date(2010,7,30), 50.52, undefined, undefined, undefined ],
 [new Date(2010,7,31), 50.25, undefined, undefined, undefined ],
 [new Date(2010,8,1), 53.11, undefined, undefined, undefined ]
 ]); }