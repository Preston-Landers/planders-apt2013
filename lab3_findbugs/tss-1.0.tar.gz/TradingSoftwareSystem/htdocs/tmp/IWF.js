
function addChartData(data) {
data.addRows([
 [new Date(2010,7,2), 49.93, undefined, undefined, undefined ],
 [new Date(2010,7,3), 49.73, undefined, undefined, undefined ],
 [new Date(2010,7,4), 50.18, undefined, undefined, undefined ],
 [new Date(2010,7,5), 50.08, undefined, undefined, undefined ],
 [new Date(2010,7,6), 49.88, undefined, undefined, undefined ],
 [new Date(2010,7,9), 50.19, undefined, undefined, undefined ],
 [new Date(2010,7,10), 49.82, undefined, undefined, undefined ],
 [new Date(2010,7,11), 48.49, undefined, undefined, undefined ],
 [new Date(2010,7,12), 48.12, undefined, undefined, undefined ],
 [new Date(2010,7,13), 47.93, undefined, undefined, undefined ],
 [new Date(2010,7,16), 47.95, undefined, undefined, undefined ],
 [new Date(2010,7,17), 48.63, undefined, undefined, undefined ],
 [new Date(2010,7,18), 48.7, undefined, undefined, undefined ],
 [new Date(2010,7,19), 47.97, undefined, undefined, undefined ],
 [new Date(2010,7,20), 47.85, undefined, undefined, undefined ],
 [new Date(2010,7,23), 47.63, undefined, undefined, undefined ],
 [new Date(2010,7,24), 46.83, undefined, undefined, undefined ],
 [new Date(2010,7,25), 46.99, undefined, undefined, undefined ],
 [new Date(2010,7,26), 46.64, undefined, undefined, undefined ],
 [new Date(2010,7,27), 47.38, undefined, undefined, undefined ],
 [new Date(2010,7,30), 46.71, undefined, undefined, undefined ],
 [new Date(2010,7,31), 46.61, undefined, undefined, undefined ],
 [new Date(2010,8,1), 48.0, undefined, undefined, undefined ]
 ]); }