
function addChartData(data) {
data.addRows([
 [new Date(2010,7,2), 90.86, undefined, undefined, undefined ],
 [new Date(2010,7,3), 89.72, undefined, undefined, undefined ],
 [new Date(2010,7,4), 90.7, undefined, undefined, undefined ],
 [new Date(2010,7,5), 91.05, undefined, undefined, undefined ],
 [new Date(2010,7,6), 90.7, undefined, undefined, undefined ],
 [new Date(2010,7,9), 91.56, undefined, undefined, undefined ],
 [new Date(2010,7,10), 90.95, undefined, undefined, undefined ],
 [new Date(2010,7,11), 89.17, undefined, undefined, undefined ],
 [new Date(2010,7,12), 88.87, undefined, undefined, undefined ],
 [new Date(2010,7,13), 88.11, undefined, undefined, undefined ],
 [new Date(2010,7,16), 88.21, undefined, undefined, undefined ],
 [new Date(2010,7,17), 89.45, undefined, undefined, undefined ],
 [new Date(2010,7,18), 90.19, undefined, undefined, undefined ],
 [new Date(2010,7,19), 88.87, undefined, undefined, undefined ],
 [new Date(2010,7,20), 88.99, undefined, undefined, undefined ],
 [new Date(2010,7,23), 88.67, undefined, undefined, undefined ],
 [new Date(2010,7,24), 87.99, undefined, undefined, undefined ],
 [new Date(2010,7,25), 89.01, undefined, undefined, undefined ],
 [new Date(2010,7,26), 88.17, undefined, undefined, undefined ],
 [new Date(2010,7,27), 88.78, undefined, undefined, undefined ],
 [new Date(2010,7,30), 87.3, undefined, undefined, undefined ],
 [new Date(2010,7,31), 86.97, undefined, undefined, undefined ],
 [new Date(2010,8,1), 89.71, undefined, undefined, undefined ]
 ]); }