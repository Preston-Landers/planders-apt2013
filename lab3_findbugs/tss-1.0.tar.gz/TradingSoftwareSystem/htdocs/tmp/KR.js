
function addChartData(data) {
data.addRows([
 [new Date(2010,7,2), 21.38, undefined, undefined, undefined ],
 [new Date(2010,7,3), 21.58, undefined, undefined, undefined ],
 [new Date(2010,7,4), 21.77, undefined, undefined, undefined ],
 [new Date(2010,7,5), 21.99, undefined, undefined, undefined ],
 [new Date(2010,7,6), 22.2, undefined, undefined, undefined ],
 [new Date(2010,7,9), 22.19, undefined, undefined, undefined ],
 [new Date(2010,7,10), 22.43, undefined, undefined, undefined ],
 [new Date(2010,7,11), 22.01, undefined, undefined, undefined ],
 [new Date(2010,7,12), 21.94, undefined, undefined, undefined ],
 [new Date(2010,7,13), 22.0, undefined, undefined, undefined ],
 [new Date(2010,7,16), 21.92, undefined, undefined, undefined ],
 [new Date(2010,7,17), 22.03, undefined, undefined, undefined ],
 [new Date(2010,7,18), 21.4, undefined, undefined, undefined ],
 [new Date(2010,7,19), 21.09, undefined, undefined, undefined ],
 [new Date(2010,7,20), 21.13, undefined, undefined, undefined ],
 [new Date(2010,7,23), 20.91, undefined, undefined, undefined ],
 [new Date(2010,7,24), 20.54, undefined, undefined, undefined ],
 [new Date(2010,7,25), 20.69, undefined, undefined, undefined ],
 [new Date(2010,7,26), 20.36, undefined, undefined, undefined ],
 [new Date(2010,7,27), 20.33, undefined, undefined, undefined ],
 [new Date(2010,7,30), 19.92, undefined, undefined, undefined ],
 [new Date(2010,7,31), 19.73, undefined, undefined, undefined ],
 [new Date(2010,8,1), 20.06, undefined, undefined, undefined ]
 ]); }