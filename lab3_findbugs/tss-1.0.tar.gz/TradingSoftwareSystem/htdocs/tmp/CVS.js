
function addChartData(data) {
data.addRows([
 [new Date(2010,7,2), 31.12, undefined, undefined, undefined ],
 [new Date(2010,7,3), 30.86, undefined, undefined, undefined ],
 [new Date(2010,7,4), 30.56, undefined, undefined, undefined ],
 [new Date(2010,7,5), 30.12, undefined, undefined, undefined ],
 [new Date(2010,7,6), 29.84, undefined, undefined, undefined ],
 [new Date(2010,7,9), 30.0, undefined, undefined, undefined ],
 [new Date(2010,7,10), 29.68, undefined, undefined, undefined ],
 [new Date(2010,7,11), 28.62, undefined, undefined, undefined ],
 [new Date(2010,7,12), 28.94, undefined, undefined, undefined ],
 [new Date(2010,7,13), 28.7, undefined, undefined, undefined ],
 [new Date(2010,7,16), 28.7, undefined, undefined, undefined ],
 [new Date(2010,7,17), 28.88, undefined, undefined, undefined ],
 [new Date(2010,7,18), 29.05, undefined, undefined, undefined ],
 [new Date(2010,7,19), 28.52, undefined, undefined, undefined ],
 [new Date(2010,7,20), 27.99, undefined, undefined, undefined ],
 [new Date(2010,7,23), 28.47, undefined, undefined, undefined ],
 [new Date(2010,7,24), 27.93, undefined, undefined, undefined ],
 [new Date(2010,7,25), 28.03, undefined, undefined, undefined ],
 [new Date(2010,7,26), 27.76, undefined, undefined, undefined ],
 [new Date(2010,7,27), 27.51, undefined, undefined, undefined ],
 [new Date(2010,7,30), 27.42, undefined, undefined, undefined ],
 [new Date(2010,7,31), 26.98, undefined, undefined, undefined ],
 [new Date(2010,8,1), 27.98, undefined, undefined, undefined ]
 ]); }