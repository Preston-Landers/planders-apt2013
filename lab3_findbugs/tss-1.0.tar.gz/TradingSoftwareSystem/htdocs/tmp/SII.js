
function addChartData(data) {
data.addRows([
 [new Date(2010,7,2), 43.61, undefined, undefined, undefined ],
 [new Date(2010,7,3), 43.68, undefined, undefined, undefined ],
 [new Date(2010,7,4), 43.68, undefined, undefined, undefined ],
 [new Date(2010,7,5), 43.88, undefined, undefined, undefined ],
 [new Date(2010,7,6), 43.35, undefined, undefined, undefined ],
 [new Date(2010,7,9), 43.58, undefined, undefined, undefined ],
 [new Date(2010,7,10), 43.23, undefined, undefined, undefined ],
 [new Date(2010,7,11), 41.73, undefined, undefined, undefined ],
 [new Date(2010,7,12), 41.17, undefined, undefined, undefined ],
 [new Date(2010,7,13), 40.82, undefined, undefined, undefined ],
 [new Date(2010,7,16), 41.26, undefined, undefined, undefined ],
 [new Date(2010,7,17), 42.0, undefined, undefined, undefined ],
 [new Date(2010,7,18), 41.18, undefined, undefined, undefined ],
 [new Date(2010,7,19), 40.17, undefined, undefined, undefined ],
 [new Date(2010,7,20), 39.24, undefined, undefined, undefined ],
 [new Date(2010,7,23), 38.85, undefined, undefined, undefined ],
 [new Date(2010,7,24), 38.13, undefined, undefined, undefined ],
 [new Date(2010,7,25), 38.01, undefined, undefined, undefined ],
 [new Date(2010,7,26), 37.16, undefined, undefined, undefined ],
 [new Date(2010,7,27), 38.84, undefined, undefined, undefined ],
 [new Date(2010,7,26), 37.16, 'Buy', 'Bought 1000 shares.', undefined ],
 [new Date(2010,7,27), 38.84, 'Sell', 'Sold 1000 shares.', null ],
 [new Date(2010,7,27), undefined, undefined, undefined, 1680.0000000000068 ]
 ]); }