
function addChartData(data) {
data.addRows([
 [new Date(2010,7,2), 202.52, undefined, undefined, undefined ],
 [new Date(2010,7,3), 200.91, undefined, undefined, undefined ],
 [new Date(2010,7,4), 205.3, undefined, undefined, undefined ],
 [new Date(2010,7,5), 201.63, undefined, undefined, undefined ],
 [new Date(2010,7,6), 207.42, undefined, undefined, undefined ],
 [new Date(2010,7,9), 214.89, undefined, undefined, undefined ],
 [new Date(2010,7,10), 216.35, undefined, undefined, undefined ],
 [new Date(2010,7,11), 209.66, undefined, undefined, undefined ],
 [new Date(2010,7,12), 211.83, undefined, undefined, undefined ],
 [new Date(2010,7,13), 210.64, undefined, undefined, undefined ],
 [new Date(2010,7,16), 210.44, undefined, undefined, undefined ],
 [new Date(2010,7,17), 214.03, undefined, undefined, undefined ],
 [new Date(2010,7,18), 212.86, undefined, undefined, undefined ],
 [new Date(2010,7,19), 208.89, undefined, undefined, undefined ],
 [new Date(2010,7,20), 206.37, undefined, undefined, undefined ],
 [new Date(2010,7,23), 205.19, undefined, undefined, undefined ],
 [new Date(2010,7,24), 202.51, undefined, undefined, undefined ],
 [new Date(2010,7,25), 206.11, undefined, undefined, undefined ],
 [new Date(2010,7,26), 203.17, undefined, undefined, undefined ],
 [new Date(2010,7,27), 206.62, undefined, undefined, undefined ],
 [new Date(2010,7,30), 202.7, undefined, undefined, undefined ],
 [new Date(2010,7,31), 198.36, undefined, undefined, undefined ],
 [new Date(2010,8,1), 201.08, undefined, undefined, undefined ]
 ]); }