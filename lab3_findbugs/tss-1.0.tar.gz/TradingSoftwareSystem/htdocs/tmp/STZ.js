
function addChartData(data) {
data.addRows([
 [new Date(2010,7,2), 17.42, undefined, undefined, undefined ],
 [new Date(2010,7,3), 17.32, undefined, undefined, undefined ],
 [new Date(2010,7,4), 17.55, undefined, undefined, undefined ],
 [new Date(2010,7,5), 17.31, undefined, undefined, undefined ],
 [new Date(2010,7,6), 17.25, undefined, undefined, undefined ],
 [new Date(2010,7,9), 17.37, undefined, undefined, undefined ],
 [new Date(2010,7,10), 17.36, undefined, undefined, undefined ],
 [new Date(2010,7,11), 16.9, undefined, undefined, undefined ],
 [new Date(2010,7,12), 16.91, undefined, undefined, undefined ],
 [new Date(2010,7,13), 16.7, undefined, undefined, undefined ],
 [new Date(2010,7,16), 16.49, undefined, undefined, undefined ],
 [new Date(2010,7,17), 16.87, undefined, undefined, undefined ],
 [new Date(2010,7,18), 16.85, undefined, undefined, undefined ],
 [new Date(2010,7,19), 16.68, undefined, undefined, undefined ],
 [new Date(2010,7,20), 16.66, undefined, undefined, undefined ],
 [new Date(2010,7,23), 16.68, undefined, undefined, undefined ],
 [new Date(2010,7,24), 16.61, undefined, undefined, undefined ],
 [new Date(2010,7,25), 16.75, undefined, undefined, undefined ],
 [new Date(2010,7,26), 16.68, undefined, undefined, undefined ],
 [new Date(2010,7,27), 16.84, undefined, undefined, undefined ],
 [new Date(2010,7,30), 16.55, undefined, undefined, undefined ],
 [new Date(2010,7,31), 16.66, undefined, undefined, undefined ],
 [new Date(2010,8,1), 16.96, undefined, undefined, undefined ]
 ]); }