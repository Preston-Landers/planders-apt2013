
function addChartData(data) {
data.addRows([
 [new Date(2010,7,2), 50.83, undefined, undefined, undefined ],
 [new Date(2010,7,3), 50.66, undefined, undefined, undefined ],
 [new Date(2010,7,4), 50.6, undefined, undefined, undefined ],
 [new Date(2010,7,5), 50.88, undefined, undefined, undefined ],
 [new Date(2010,7,6), 50.87, undefined, undefined, undefined ],
 [new Date(2010,7,9), 51.37, undefined, undefined, undefined ],
 [new Date(2010,7,10), 50.8, undefined, undefined, undefined ],
 [new Date(2010,7,11), 49.84, undefined, undefined, undefined ],
 [new Date(2010,7,12), 49.63, undefined, undefined, undefined ],
 [new Date(2010,7,13), 49.19, undefined, undefined, undefined ],
 [new Date(2010,7,16), 50.07, undefined, undefined, undefined ],
 [new Date(2010,7,17), 51.01, undefined, undefined, undefined ],
 [new Date(2010,7,18), 51.6, undefined, undefined, undefined ],
 [new Date(2010,7,19), 50.93, undefined, undefined, undefined ],
 [new Date(2010,7,20), 51.26, undefined, undefined, undefined ],
 [new Date(2010,7,23), 50.74, undefined, undefined, undefined ],
 [new Date(2010,7,24), 50.24, undefined, undefined, undefined ],
 [new Date(2010,7,25), 50.46, undefined, undefined, undefined ],
 [new Date(2010,7,26), 50.14, undefined, undefined, undefined ],
 [new Date(2010,7,27), 50.99, undefined, undefined, undefined ],
 [new Date(2010,7,30), 50.06, undefined, undefined, undefined ],
 [new Date(2010,7,31), 50.01, undefined, undefined, undefined ],
 [new Date(2010,8,1), 51.65, undefined, undefined, undefined ]
 ]); }