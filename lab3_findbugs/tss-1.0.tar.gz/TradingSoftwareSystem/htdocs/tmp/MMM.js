
function addChartData(data) {
data.addRows([
 [new Date(2010,7,2), 87.41, undefined, undefined, undefined ],
 [new Date(2010,7,3), 87.21, undefined, undefined, undefined ],
 [new Date(2010,7,4), 88.0, undefined, undefined, undefined ],
 [new Date(2010,7,5), 87.72, undefined, undefined, undefined ],
 [new Date(2010,7,6), 87.29, undefined, undefined, undefined ],
 [new Date(2010,7,9), 88.03, undefined, undefined, undefined ],
 [new Date(2010,7,10), 87.11, undefined, undefined, undefined ],
 [new Date(2010,7,11), 84.1, undefined, undefined, undefined ],
 [new Date(2010,7,12), 84.01, undefined, undefined, undefined ],
 [new Date(2010,7,13), 84.01, undefined, undefined, undefined ],
 [new Date(2010,7,16), 83.43, undefined, undefined, undefined ],
 [new Date(2010,7,17), 84.09, undefined, undefined, undefined ],
 [new Date(2010,7,18), 83.61, undefined, undefined, undefined ],
 [new Date(2010,7,19), 81.81, undefined, undefined, undefined ],
 [new Date(2010,7,20), 80.66, undefined, undefined, undefined ],
 [new Date(2010,7,23), 81.08, undefined, undefined, undefined ],
 [new Date(2010,7,24), 80.45, undefined, undefined, undefined ],
 [new Date(2010,7,25), 80.75, undefined, undefined, undefined ],
 [new Date(2010,7,26), 79.78, undefined, undefined, undefined ],
 [new Date(2010,7,27), 81.0, undefined, undefined, undefined ],
 [new Date(2010,7,30), 79.65, undefined, undefined, undefined ],
 [new Date(2010,7,31), 78.55, undefined, undefined, undefined ],
 [new Date(2010,8,1), 81.01, undefined, undefined, undefined ]
 ]); }