
function addChartData(data) {
data.addRows([
 [new Date(2010,7,2), 63.57, undefined, undefined, undefined ],
 [new Date(2010,7,3), 63.67, undefined, undefined, undefined ],
 [new Date(2010,7,4), 64.38, undefined, undefined, undefined ],
 [new Date(2010,7,5), 64.16, undefined, undefined, undefined ],
 [new Date(2010,7,6), 64.26, undefined, undefined, undefined ],
 [new Date(2010,7,9), 64.93, undefined, undefined, undefined ],
 [new Date(2010,7,10), 64.57, undefined, undefined, undefined ],
 [new Date(2010,7,11), 63.62, undefined, undefined, undefined ],
 [new Date(2010,7,12), 64.52, undefined, undefined, undefined ],
 [new Date(2010,7,13), 64.76, undefined, undefined, undefined ],
 [new Date(2010,7,16), 65.76, undefined, undefined, undefined ],
 [new Date(2010,7,17), 67.0, undefined, undefined, undefined ],
 [new Date(2010,7,18), 67.06, undefined, undefined, undefined ],
 [new Date(2010,7,19), 66.12, undefined, undefined, undefined ],
 [new Date(2010,7,20), 65.92, undefined, undefined, undefined ],
 [new Date(2010,7,23), 65.82, undefined, undefined, undefined ],
 [new Date(2010,7,24), 65.2, undefined, undefined, undefined ],
 [new Date(2010,7,25), 64.88, undefined, undefined, undefined ],
 [new Date(2010,7,26), 64.58, undefined, undefined, undefined ],
 [new Date(2010,7,27), 66.04, undefined, undefined, undefined ],
 [new Date(2010,7,30), 66.25, undefined, undefined, undefined ],
 [new Date(2010,7,31), 65.5, undefined, undefined, undefined ],
 [new Date(2010,8,1), 66.56, undefined, undefined, undefined ]
 ]); }