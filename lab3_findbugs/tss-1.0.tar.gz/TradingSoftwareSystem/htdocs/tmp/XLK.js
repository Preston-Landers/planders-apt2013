
function addChartData(data) {
data.addRows([
 [new Date(2010,7,2), 22.38, undefined, undefined, undefined ],
 [new Date(2010,7,3), 22.26, undefined, undefined, undefined ],
 [new Date(2010,7,4), 22.44, undefined, undefined, undefined ],
 [new Date(2010,7,5), 22.34, undefined, undefined, undefined ],
 [new Date(2010,7,6), 22.28, undefined, undefined, undefined ],
 [new Date(2010,7,9), 22.43, undefined, undefined, undefined ],
 [new Date(2010,7,10), 22.2, undefined, undefined, undefined ],
 [new Date(2010,7,11), 21.67, undefined, undefined, undefined ],
 [new Date(2010,7,12), 21.37, undefined, undefined, undefined ],
 [new Date(2010,7,13), 21.27, undefined, undefined, undefined ],
 [new Date(2010,7,16), 21.31, undefined, undefined, undefined ],
 [new Date(2010,7,17), 21.54, undefined, undefined, undefined ],
 [new Date(2010,7,18), 21.66, undefined, undefined, undefined ],
 [new Date(2010,7,19), 21.4, undefined, undefined, undefined ],
 [new Date(2010,7,20), 21.35, undefined, undefined, undefined ],
 [new Date(2010,7,23), 21.16, undefined, undefined, undefined ],
 [new Date(2010,7,24), 20.87, undefined, undefined, undefined ],
 [new Date(2010,7,25), 21.0, undefined, undefined, undefined ],
 [new Date(2010,7,26), 20.79, undefined, undefined, undefined ],
 [new Date(2010,7,27), 21.04, undefined, undefined, undefined ],
 [new Date(2010,7,30), 20.76, undefined, undefined, undefined ],
 [new Date(2010,7,31), 20.69, undefined, undefined, undefined ],
 [new Date(2010,8,1), 21.22, undefined, undefined, undefined ]
 ]); }