
function addChartData(data) {
data.addRows([
 [new Date(2010,7,2), 53.83, undefined, undefined, undefined ],
 [new Date(2010,7,3), 54.19, undefined, undefined, undefined ],
 [new Date(2010,7,4), 54.83, undefined, undefined, undefined ],
 [new Date(2010,7,5), 54.5, undefined, undefined, undefined ],
 [new Date(2010,7,6), 53.98, undefined, undefined, undefined ],
 [new Date(2010,7,9), 53.99, undefined, undefined, undefined ],
 [new Date(2010,7,10), 53.9, undefined, undefined, undefined ],
 [new Date(2010,7,11), 52.01, undefined, undefined, undefined ],
 [new Date(2010,7,12), 52.0, undefined, undefined, undefined ],
 [new Date(2010,7,13), 51.44, undefined, undefined, undefined ],
 [new Date(2010,7,16), 51.0, undefined, undefined, undefined ],
 [new Date(2010,7,17), 51.21, undefined, undefined, undefined ],
 [new Date(2010,7,18), 51.87, undefined, undefined, undefined ],
 [new Date(2010,7,19), 50.22, undefined, undefined, undefined ],
 [new Date(2010,7,20), 49.82, undefined, undefined, undefined ],
 [new Date(2010,7,23), 49.37, undefined, undefined, undefined ],
 [new Date(2010,7,24), 46.97, undefined, undefined, undefined ],
 [new Date(2010,7,25), 47.72, undefined, undefined, undefined ],
 [new Date(2010,7,26), 47.28, undefined, undefined, undefined ],
 [new Date(2010,7,27), 48.01, undefined, undefined, undefined ],
 [new Date(2010,7,30), 47.53, undefined, undefined, undefined ],
 [new Date(2010,7,31), 47.17, undefined, undefined, undefined ],
 [new Date(2010,8,1), 47.7, undefined, undefined, undefined ]
 ]); }