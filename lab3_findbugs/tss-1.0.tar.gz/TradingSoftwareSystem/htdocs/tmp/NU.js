
function addChartData(data) {
data.addRows([
 [new Date(2010,7,2), 28.5, undefined, undefined, undefined ],
 [new Date(2010,7,3), 28.3, undefined, undefined, undefined ],
 [new Date(2010,7,4), 28.77, undefined, undefined, undefined ],
 [new Date(2010,7,5), 29.14, undefined, undefined, undefined ],
 [new Date(2010,7,6), 28.97, undefined, undefined, undefined ],
 [new Date(2010,7,9), 29.03, undefined, undefined, undefined ],
 [new Date(2010,7,10), 29.2, undefined, undefined, undefined ],
 [new Date(2010,7,11), 28.91, undefined, undefined, undefined ],
 [new Date(2010,7,12), 28.63, undefined, undefined, undefined ],
 [new Date(2010,7,13), 28.75, undefined, undefined, undefined ],
 [new Date(2010,7,16), 28.85, undefined, undefined, undefined ],
 [new Date(2010,7,17), 29.24, undefined, undefined, undefined ],
 [new Date(2010,7,18), 28.99, undefined, undefined, undefined ],
 [new Date(2010,7,19), 28.6, undefined, undefined, undefined ],
 [new Date(2010,7,20), 28.54, undefined, undefined, undefined ],
 [new Date(2010,7,23), 28.65, undefined, undefined, undefined ],
 [new Date(2010,7,24), 28.78, undefined, undefined, undefined ],
 [new Date(2010,7,25), 28.9, undefined, undefined, undefined ],
 [new Date(2010,7,26), 28.58, undefined, undefined, undefined ],
 [new Date(2010,7,27), 29.22, undefined, undefined, undefined ],
 [new Date(2010,7,30), 28.65, undefined, undefined, undefined ],
 [new Date(2010,7,31), 28.97, undefined, undefined, undefined ],
 [new Date(2010,8,1), 29.64, undefined, undefined, undefined ]
 ]); }