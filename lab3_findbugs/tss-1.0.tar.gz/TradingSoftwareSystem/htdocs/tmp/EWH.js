
function addChartData(data) {
data.addRows([
 [new Date(2010,7,2), 16.3, undefined, undefined, undefined ],
 [new Date(2010,7,3), 16.29, undefined, undefined, undefined ],
 [new Date(2010,7,4), 16.32, undefined, undefined, undefined ],
 [new Date(2010,7,5), 16.35, undefined, undefined, undefined ],
 [new Date(2010,7,6), 16.44, undefined, undefined, undefined ],
 [new Date(2010,7,9), 16.64, undefined, undefined, undefined ],
 [new Date(2010,7,10), 16.5, undefined, undefined, undefined ],
 [new Date(2010,7,11), 16.26, undefined, undefined, undefined ],
 [new Date(2010,7,12), 16.24, undefined, undefined, undefined ],
 [new Date(2010,7,13), 16.25, undefined, undefined, undefined ],
 [new Date(2010,7,16), 16.17, undefined, undefined, undefined ],
 [new Date(2010,7,17), 16.18, undefined, undefined, undefined ],
 [new Date(2010,7,18), 16.19, undefined, undefined, undefined ],
 [new Date(2010,7,19), 16.14, undefined, undefined, undefined ],
 [new Date(2010,7,20), 16.16, undefined, undefined, undefined ],
 [new Date(2010,7,23), 16.08, undefined, undefined, undefined ],
 [new Date(2010,7,24), 15.99, undefined, undefined, undefined ],
 [new Date(2010,7,25), 16.05, undefined, undefined, undefined ],
 [new Date(2010,7,26), 16.0, undefined, undefined, undefined ],
 [new Date(2010,7,27), 16.14, undefined, undefined, undefined ],
 [new Date(2010,7,30), 16.0, undefined, undefined, undefined ],
 [new Date(2010,7,31), 15.99, undefined, undefined, undefined ],
 [new Date(2010,8,1), 16.36, undefined, undefined, undefined ]
 ]); }