
function addChartData(data) {
data.addRows([
 [new Date(2010,7,2), 113.13, undefined, undefined, undefined ],
 [new Date(2010,7,3), 112.58, undefined, undefined, undefined ],
 [new Date(2010,7,4), 113.39, undefined, undefined, undefined ],
 [new Date(2010,7,5), 113.26, undefined, undefined, undefined ],
 [new Date(2010,7,6), 112.78, undefined, undefined, undefined ],
 [new Date(2010,7,9), 113.39, undefined, undefined, undefined ],
 [new Date(2010,7,10), 112.82, undefined, undefined, undefined ],
 [new Date(2010,7,11), 109.7, undefined, undefined, undefined ],
 [new Date(2010,7,12), 109.0, undefined, undefined, undefined ],
 [new Date(2010,7,13), 108.69, undefined, undefined, undefined ],
 [new Date(2010,7,16), 108.66, undefined, undefined, undefined ],
 [new Date(2010,7,17), 109.97, undefined, undefined, undefined ],
 [new Date(2010,7,18), 110.16, undefined, undefined, undefined ],
 [new Date(2010,7,19), 108.3, undefined, undefined, undefined ],
 [new Date(2010,7,20), 107.9, undefined, undefined, undefined ],
 [new Date(2010,7,23), 107.5, undefined, undefined, undefined ],
 [new Date(2010,7,24), 105.95, undefined, undefined, undefined ],
 [new Date(2010,7,25), 106.29, undefined, undefined, undefined ],
 [new Date(2010,7,26), 105.6, undefined, undefined, undefined ],
 [new Date(2010,7,27), 107.22, undefined, undefined, undefined ],
 [new Date(2010,7,30), 105.71, undefined, undefined, undefined ],
 [new Date(2010,7,31), 105.79, undefined, undefined, undefined ],
 [new Date(2010,8,1), 108.83, undefined, undefined, undefined ]
 ]); }