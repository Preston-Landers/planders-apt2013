
function addChartData(data) {
data.addRows([
 [new Date(2010,7,2), 49.83, undefined, undefined, undefined ],
 [new Date(2010,7,3), 50.0, undefined, undefined, undefined ],
 [new Date(2010,7,4), 50.18, undefined, undefined, undefined ],
 [new Date(2010,7,5), 49.98, undefined, undefined, undefined ],
 [new Date(2010,7,6), 50.57, undefined, undefined, undefined ],
 [new Date(2010,7,9), 50.88, undefined, undefined, undefined ],
 [new Date(2010,7,10), 51.47, undefined, undefined, undefined ],
 [new Date(2010,7,11), 50.39, undefined, undefined, undefined ],
 [new Date(2010,7,12), 50.39, undefined, undefined, undefined ],
 [new Date(2010,7,13), 50.06, undefined, undefined, undefined ],
 [new Date(2010,7,16), 50.34, undefined, undefined, undefined ],
 [new Date(2010,7,17), 50.69, undefined, undefined, undefined ],
 [new Date(2010,7,18), 50.23, undefined, undefined, undefined ],
 [new Date(2010,7,19), 49.32, undefined, undefined, undefined ],
 [new Date(2010,7,20), 49.34, undefined, undefined, undefined ],
 [new Date(2010,7,23), 49.78, undefined, undefined, undefined ],
 [new Date(2010,7,24), 49.48, undefined, undefined, undefined ],
 [new Date(2010,7,25), 49.82, undefined, undefined, undefined ],
 [new Date(2010,7,26), 49.5, undefined, undefined, undefined ],
 [new Date(2010,7,27), 49.84, undefined, undefined, undefined ],
 [new Date(2010,7,30), 49.49, undefined, undefined, undefined ],
 [new Date(2010,7,31), 49.34, undefined, undefined, undefined ],
 [new Date(2010,8,1), 50.27, undefined, undefined, undefined ]
 ]); }