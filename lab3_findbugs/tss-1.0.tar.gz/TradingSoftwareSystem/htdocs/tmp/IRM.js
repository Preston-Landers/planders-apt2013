
function addChartData(data) {
data.addRows([
 [new Date(2010,7,2), 24.37, undefined, undefined, undefined ],
 [new Date(2010,7,3), 23.69, undefined, undefined, undefined ],
 [new Date(2010,7,4), 23.61, undefined, undefined, undefined ],
 [new Date(2010,7,5), 23.52, undefined, undefined, undefined ],
 [new Date(2010,7,6), 23.23, undefined, undefined, undefined ],
 [new Date(2010,7,9), 23.35, undefined, undefined, undefined ],
 [new Date(2010,7,10), 23.11, undefined, undefined, undefined ],
 [new Date(2010,7,11), 22.28, undefined, undefined, undefined ],
 [new Date(2010,7,12), 22.18, undefined, undefined, undefined ],
 [new Date(2010,7,13), 21.97, undefined, undefined, undefined ],
 [new Date(2010,7,16), 22.0, undefined, undefined, undefined ],
 [new Date(2010,7,17), 22.01, undefined, undefined, undefined ],
 [new Date(2010,7,18), 21.91, undefined, undefined, undefined ],
 [new Date(2010,7,19), 21.42, undefined, undefined, undefined ],
 [new Date(2010,7,20), 21.58, undefined, undefined, undefined ],
 [new Date(2010,7,23), 21.31, undefined, undefined, undefined ],
 [new Date(2010,7,24), 20.99, undefined, undefined, undefined ],
 [new Date(2010,7,25), 20.95, undefined, undefined, undefined ],
 [new Date(2010,7,26), 20.43, undefined, undefined, undefined ],
 [new Date(2010,7,27), 20.76, undefined, undefined, undefined ],
 [new Date(2010,7,30), 20.32, undefined, undefined, undefined ],
 [new Date(2010,7,31), 20.28, undefined, undefined, undefined ],
 [new Date(2010,8,1), 20.52, undefined, undefined, undefined ]
 ]); }