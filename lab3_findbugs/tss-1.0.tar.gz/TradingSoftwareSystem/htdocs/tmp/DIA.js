
function addChartData(data) {
data.addRows([
 [new Date(2010,7,2), 106.73, undefined, undefined, undefined ],
 [new Date(2010,7,3), 106.39, undefined, undefined, undefined ],
 [new Date(2010,7,4), 106.96, undefined, undefined, undefined ],
 [new Date(2010,7,5), 106.88, undefined, undefined, undefined ],
 [new Date(2010,7,6), 106.69, undefined, undefined, undefined ],
 [new Date(2010,7,9), 107.12, undefined, undefined, undefined ],
 [new Date(2010,7,10), 106.66, undefined, undefined, undefined ],
 [new Date(2010,7,11), 104.13, undefined, undefined, undefined ],
 [new Date(2010,7,12), 103.45, undefined, undefined, undefined ],
 [new Date(2010,7,13), 103.35, undefined, undefined, undefined ],
 [new Date(2010,7,16), 103.28, undefined, undefined, undefined ],
 [new Date(2010,7,17), 104.33, undefined, undefined, undefined ],
 [new Date(2010,7,18), 104.57, undefined, undefined, undefined ],
 [new Date(2010,7,19), 103.06, undefined, undefined, undefined ],
 [new Date(2010,7,20), 102.14, undefined, undefined, undefined ],
 [new Date(2010,7,23), 101.76, undefined, undefined, undefined ],
 [new Date(2010,7,24), 100.4, undefined, undefined, undefined ],
 [new Date(2010,7,25), 100.61, undefined, undefined, undefined ],
 [new Date(2010,7,26), 99.93, undefined, undefined, undefined ],
 [new Date(2010,7,27), 101.58, undefined, undefined, undefined ],
 [new Date(2010,7,30), 100.17, undefined, undefined, undefined ],
 [new Date(2010,7,31), 100.2, undefined, undefined, undefined ],
 [new Date(2010,8,1), 102.8, undefined, undefined, undefined ]
 ]); }