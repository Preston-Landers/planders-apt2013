
function addChartData(data) {
data.addRows([
 [new Date(2010,7,2), 38.52, undefined, undefined, undefined ],
 [new Date(2010,7,3), 39.06, undefined, undefined, undefined ],
 [new Date(2010,7,4), 39.48, undefined, undefined, undefined ],
 [new Date(2010,7,5), 39.62, undefined, undefined, undefined ],
 [new Date(2010,7,6), 39.34, undefined, undefined, undefined ],
 [new Date(2010,7,9), 39.51, undefined, undefined, undefined ],
 [new Date(2010,7,10), 39.8, undefined, undefined, undefined ],
 [new Date(2010,7,11), 39.05, undefined, undefined, undefined ],
 [new Date(2010,7,12), 39.35, undefined, undefined, undefined ],
 [new Date(2010,7,13), 39.5, undefined, undefined, undefined ],
 [new Date(2010,7,16), 39.42, undefined, undefined, undefined ],
 [new Date(2010,7,17), 40.25, undefined, undefined, undefined ],
 [new Date(2010,7,18), 39.74, undefined, undefined, undefined ],
 [new Date(2010,7,19), 39.24, undefined, undefined, undefined ],
 [new Date(2010,7,20), 39.28, undefined, undefined, undefined ],
 [new Date(2010,7,23), 39.75, undefined, undefined, undefined ],
 [new Date(2010,7,24), 39.98, undefined, undefined, undefined ],
 [new Date(2010,7,25), 39.93, undefined, undefined, undefined ],
 [new Date(2010,7,26), 39.62, undefined, undefined, undefined ],
 [new Date(2010,7,27), 40.34, undefined, undefined, undefined ],
 [new Date(2010,7,30), 39.73, undefined, undefined, undefined ],
 [new Date(2010,7,31), 39.85, undefined, undefined, undefined ],
 [new Date(2010,8,1), 40.9, undefined, undefined, undefined ]
 ]); }