
function addChartData(data) {
data.addRows([
 [new Date(2010,7,2), 26.59, undefined, undefined, undefined ],
 [new Date(2010,7,3), 26.69, undefined, undefined, undefined ],
 [new Date(2010,7,4), 26.64, undefined, undefined, undefined ],
 [new Date(2010,7,5), 26.74, undefined, undefined, undefined ],
 [new Date(2010,7,6), 26.54, undefined, undefined, undefined ],
 [new Date(2010,7,9), 26.86, undefined, undefined, undefined ],
 [new Date(2010,7,10), 27.01, undefined, undefined, undefined ],
 [new Date(2010,7,11), 26.55, undefined, undefined, undefined ],
 [new Date(2010,7,12), 26.66, undefined, undefined, undefined ],
 [new Date(2010,7,13), 26.72, undefined, undefined, undefined ],
 [new Date(2010,7,16), 26.65, undefined, undefined, undefined ],
 [new Date(2010,7,17), 26.97, undefined, undefined, undefined ],
 [new Date(2010,7,18), 27.28, undefined, undefined, undefined ],
 [new Date(2010,7,19), 26.97, undefined, undefined, undefined ],
 [new Date(2010,7,20), 26.45, undefined, undefined, undefined ],
 [new Date(2010,7,23), 26.49, undefined, undefined, undefined ],
 [new Date(2010,7,24), 26.72, undefined, undefined, undefined ],
 [new Date(2010,7,25), 26.89, undefined, undefined, undefined ],
 [new Date(2010,7,26), 26.7, undefined, undefined, undefined ],
 [new Date(2010,7,27), 26.94, undefined, undefined, undefined ],
 [new Date(2010,7,30), 26.63, undefined, undefined, undefined ],
 [new Date(2010,7,31), 27.03, undefined, undefined, undefined ],
 [new Date(2010,8,1), 27.35, undefined, undefined, undefined ]
 ]); }