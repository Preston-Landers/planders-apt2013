
function addChartData(data) {
data.addRows([
 [new Date(2010,7,2), 46.67, undefined, undefined, undefined ],
 [new Date(2010,7,3), 46.47, undefined, undefined, undefined ],
 [new Date(2010,7,4), 46.94, undefined, undefined, undefined ],
 [new Date(2010,7,5), 46.83, undefined, undefined, undefined ],
 [new Date(2010,7,6), 46.76, undefined, undefined, undefined ],
 [new Date(2010,7,9), 47.08, undefined, undefined, undefined ],
 [new Date(2010,7,10), 46.67, undefined, undefined, undefined ],
 [new Date(2010,7,11), 45.4, undefined, undefined, undefined ],
 [new Date(2010,7,12), 45.04, undefined, undefined, undefined ],
 [new Date(2010,7,13), 44.72, undefined, undefined, undefined ],
 [new Date(2010,7,16), 44.8, undefined, undefined, undefined ],
 [new Date(2010,7,17), 45.37, undefined, undefined, undefined ],
 [new Date(2010,7,18), 45.55, undefined, undefined, undefined ],
 [new Date(2010,7,19), 44.86, undefined, undefined, undefined ],
 [new Date(2010,7,20), 44.92, undefined, undefined, undefined ],
 [new Date(2010,7,23), 44.48, undefined, undefined, undefined ],
 [new Date(2010,7,24), 43.65, undefined, undefined, undefined ],
 [new Date(2010,7,25), 44.07, undefined, undefined, undefined ],
 [new Date(2010,7,26), 43.54, undefined, undefined, undefined ],
 [new Date(2010,7,27), 44.07, undefined, undefined, undefined ],
 [new Date(2010,7,30), 43.61, undefined, undefined, undefined ],
 [new Date(2010,7,31), 43.46, undefined, undefined, undefined ],
 [new Date(2010,8,1), 44.76, undefined, undefined, undefined ]
 ]); }