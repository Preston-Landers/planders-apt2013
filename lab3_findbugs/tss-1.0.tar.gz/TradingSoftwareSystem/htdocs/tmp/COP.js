
function addChartData(data) {
data.addRows([
 [new Date(2010,7,2), 57.53, undefined, undefined, undefined ],
 [new Date(2010,7,3), 57.56, undefined, undefined, undefined ],
 [new Date(2010,7,4), 57.42, undefined, undefined, undefined ],
 [new Date(2010,7,5), 57.7, undefined, undefined, undefined ],
 [new Date(2010,7,6), 56.93, undefined, undefined, undefined ],
 [new Date(2010,7,9), 57.31, undefined, undefined, undefined ],
 [new Date(2010,7,10), 56.87, undefined, undefined, undefined ],
 [new Date(2010,7,11), 55.51, undefined, undefined, undefined ],
 [new Date(2010,7,12), 55.35, undefined, undefined, undefined ],
 [new Date(2010,7,13), 55.02, undefined, undefined, undefined ],
 [new Date(2010,7,16), 54.93, undefined, undefined, undefined ],
 [new Date(2010,7,17), 55.87, undefined, undefined, undefined ],
 [new Date(2010,7,18), 55.42, undefined, undefined, undefined ],
 [new Date(2010,7,19), 54.71, undefined, undefined, undefined ],
 [new Date(2010,7,20), 53.89, undefined, undefined, undefined ],
 [new Date(2010,7,23), 53.71, undefined, undefined, undefined ],
 [new Date(2010,7,24), 53.43, undefined, undefined, undefined ],
 [new Date(2010,7,25), 53.46, undefined, undefined, undefined ],
 [new Date(2010,7,26), 52.41, undefined, undefined, undefined ],
 [new Date(2010,7,27), 53.42, undefined, undefined, undefined ],
 [new Date(2010,7,30), 52.67, undefined, undefined, undefined ],
 [new Date(2010,7,31), 52.43, undefined, undefined, undefined ],
 [new Date(2010,8,1), 54.06, undefined, undefined, undefined ]
 ]); }