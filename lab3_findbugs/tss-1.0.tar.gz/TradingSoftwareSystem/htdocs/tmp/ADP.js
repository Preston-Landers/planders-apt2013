
function addChartData(data) {
data.addRows([
 [new Date(2010,7,2), 41.95, undefined, undefined, undefined ],
 [new Date(2010,7,3), 42.01, undefined, undefined, undefined ],
 [new Date(2010,7,4), 42.14, undefined, undefined, undefined ],
 [new Date(2010,7,5), 41.93, undefined, undefined, undefined ],
 [new Date(2010,7,6), 41.57, undefined, undefined, undefined ],
 [new Date(2010,7,9), 41.77, undefined, undefined, undefined ],
 [new Date(2010,7,10), 41.36, undefined, undefined, undefined ],
 [new Date(2010,7,11), 40.4, undefined, undefined, undefined ],
 [new Date(2010,7,12), 40.0, undefined, undefined, undefined ],
 [new Date(2010,7,13), 39.79, undefined, undefined, undefined ],
 [new Date(2010,7,16), 40.07, undefined, undefined, undefined ],
 [new Date(2010,7,17), 40.35, undefined, undefined, undefined ],
 [new Date(2010,7,18), 40.22, undefined, undefined, undefined ],
 [new Date(2010,7,19), 39.45, undefined, undefined, undefined ],
 [new Date(2010,7,20), 39.4, undefined, undefined, undefined ],
 [new Date(2010,7,23), 39.05, undefined, undefined, undefined ],
 [new Date(2010,7,24), 38.81, undefined, undefined, undefined ],
 [new Date(2010,7,25), 38.93, undefined, undefined, undefined ],
 [new Date(2010,7,26), 38.75, undefined, undefined, undefined ],
 [new Date(2010,7,27), 39.36, undefined, undefined, undefined ],
 [new Date(2010,7,30), 38.83, undefined, undefined, undefined ],
 [new Date(2010,7,31), 38.61, undefined, undefined, undefined ],
 [new Date(2010,8,1), 39.37, undefined, undefined, undefined ]
 ]); }