
function addChartData(data) {
data.addRows([
 [new Date(2010,7,2), 41.09, undefined, undefined, undefined ],
 [new Date(2010,7,3), 40.86, undefined, undefined, undefined ],
 [new Date(2010,7,4), 41.33, undefined, undefined, undefined ],
 [new Date(2010,7,5), 41.36, undefined, undefined, undefined ],
 [new Date(2010,7,6), 41.22, undefined, undefined, undefined ],
 [new Date(2010,7,9), 41.69, undefined, undefined, undefined ],
 [new Date(2010,7,10), 41.71, undefined, undefined, undefined ],
 [new Date(2010,7,11), 41.21, undefined, undefined, undefined ],
 [new Date(2010,7,12), 41.53, undefined, undefined, undefined ],
 [new Date(2010,7,13), 41.73, undefined, undefined, undefined ],
 [new Date(2010,7,16), 42.43, undefined, undefined, undefined ],
 [new Date(2010,7,17), 42.98, undefined, undefined, undefined ],
 [new Date(2010,7,18), 42.98, undefined, undefined, undefined ],
 [new Date(2010,7,19), 42.32, undefined, undefined, undefined ],
 [new Date(2010,7,20), 42.19, undefined, undefined, undefined ],
 [new Date(2010,7,23), 42.37, undefined, undefined, undefined ],
 [new Date(2010,7,24), 42.23, undefined, undefined, undefined ],
 [new Date(2010,7,25), 42.58, undefined, undefined, undefined ],
 [new Date(2010,7,26), 42.96, undefined, undefined, undefined ],
 [new Date(2010,7,27), 43.75, undefined, undefined, undefined ],
 [new Date(2010,7,30), 43.25, undefined, undefined, undefined ],
 [new Date(2010,7,31), 43.07, undefined, undefined, undefined ],
 [new Date(2010,8,1), 44.15, undefined, undefined, undefined ]
 ]); }