
function addChartData(data) {
data.addRows([
 [new Date(2010,7,2), 5.66, undefined, undefined, undefined ],
 [new Date(2010,7,3), 5.65, undefined, undefined, undefined ],
 [new Date(2010,7,4), 5.7, undefined, undefined, undefined ],
 [new Date(2010,7,5), 5.64, undefined, undefined, undefined ],
 [new Date(2010,7,6), 5.69, undefined, undefined, undefined ],
 [new Date(2010,7,9), 5.7, undefined, undefined, undefined ],
 [new Date(2010,7,10), 5.69, undefined, undefined, undefined ],
 [new Date(2010,7,11), 5.64, undefined, undefined, undefined ],
 [new Date(2010,7,12), 5.62, undefined, undefined, undefined ],
 [new Date(2010,7,13), 5.69, undefined, undefined, undefined ],
 [new Date(2010,7,16), 5.69, undefined, undefined, undefined ],
 [new Date(2010,7,17), 5.7, undefined, undefined, undefined ],
 [new Date(2010,7,18), 5.66, undefined, undefined, undefined ],
 [new Date(2010,7,19), 5.66, undefined, undefined, undefined ],
 [new Date(2010,7,20), 5.65, undefined, undefined, undefined ],
 [new Date(2010,7,23), 5.64, undefined, undefined, undefined ],
 [new Date(2010,7,24), 5.66, undefined, undefined, undefined ],
 [new Date(2010,7,25), 5.64, undefined, undefined, undefined ],
 [new Date(2010,7,26), 5.63, undefined, undefined, undefined ],
 [new Date(2010,7,27), 5.64, undefined, undefined, undefined ],
 [new Date(2010,7,30), 5.62, undefined, undefined, undefined ],
 [new Date(2010,7,31), 5.65, undefined, undefined, undefined ],
 [new Date(2010,8,1), 5.8, undefined, undefined, undefined ]
 ]); }