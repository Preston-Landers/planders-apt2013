
function addChartData(data) {
data.addRows([
 [new Date(2010,7,2), 41.92, undefined, undefined, undefined ],
 [new Date(2010,7,3), 41.41, undefined, undefined, undefined ],
 [new Date(2010,7,4), 42.01, undefined, undefined, undefined ],
 [new Date(2010,7,5), 41.91, undefined, undefined, undefined ],
 [new Date(2010,7,6), 42.0, undefined, undefined, undefined ],
 [new Date(2010,7,9), 42.75, undefined, undefined, undefined ],
 [new Date(2010,7,10), 42.7, undefined, undefined, undefined ],
 [new Date(2010,7,11), 42.63, undefined, undefined, undefined ],
 [new Date(2010,7,12), 42.93, undefined, undefined, undefined ],
 [new Date(2010,7,13), 42.92, undefined, undefined, undefined ],
 [new Date(2010,7,16), 42.9, undefined, undefined, undefined ],
 [new Date(2010,7,17), 43.34, undefined, undefined, undefined ],
 [new Date(2010,7,18), 43.56, undefined, undefined, undefined ],
 [new Date(2010,7,19), 43.17, undefined, undefined, undefined ],
 [new Date(2010,7,20), 42.83, undefined, undefined, undefined ],
 [new Date(2010,7,23), 42.91, undefined, undefined, undefined ],
 [new Date(2010,7,24), 43.17, undefined, undefined, undefined ],
 [new Date(2010,7,25), 42.82, undefined, undefined, undefined ],
 [new Date(2010,7,26), 43.08, undefined, undefined, undefined ],
 [new Date(2010,7,27), 43.34, undefined, undefined, undefined ],
 [new Date(2010,7,30), 42.95, undefined, undefined, undefined ],
 [new Date(2010,7,31), 42.79, undefined, undefined, undefined ],
 [new Date(2010,8,1), 43.28, undefined, undefined, undefined ]
 ]); }