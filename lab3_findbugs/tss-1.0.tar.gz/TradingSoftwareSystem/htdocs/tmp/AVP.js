
function addChartData(data) {
data.addRows([
 [new Date(2010,7,2), 31.83, undefined, undefined, undefined ],
 [new Date(2010,7,3), 31.44, undefined, undefined, undefined ],
 [new Date(2010,7,4), 31.47, undefined, undefined, undefined ],
 [new Date(2010,7,5), 31.06, undefined, undefined, undefined ],
 [new Date(2010,7,6), 31.11, undefined, undefined, undefined ],
 [new Date(2010,7,9), 31.1, undefined, undefined, undefined ],
 [new Date(2010,7,10), 31.06, undefined, undefined, undefined ],
 [new Date(2010,7,11), 29.85, undefined, undefined, undefined ],
 [new Date(2010,7,12), 29.69, undefined, undefined, undefined ],
 [new Date(2010,7,13), 29.4, undefined, undefined, undefined ],
 [new Date(2010,7,16), 29.48, undefined, undefined, undefined ],
 [new Date(2010,7,17), 29.94, undefined, undefined, undefined ],
 [new Date(2010,7,18), 29.85, undefined, undefined, undefined ],
 [new Date(2010,7,19), 29.44, undefined, undefined, undefined ],
 [new Date(2010,7,20), 29.0, undefined, undefined, undefined ],
 [new Date(2010,7,23), 29.79, undefined, undefined, undefined ],
 [new Date(2010,7,24), 29.48, undefined, undefined, undefined ],
 [new Date(2010,7,25), 29.36, undefined, undefined, undefined ],
 [new Date(2010,7,26), 28.96, undefined, undefined, undefined ],
 [new Date(2010,7,27), 29.61, undefined, undefined, undefined ],
 [new Date(2010,7,30), 28.95, undefined, undefined, undefined ],
 [new Date(2010,7,31), 29.1, undefined, undefined, undefined ],
 [new Date(2010,8,1), 29.31, undefined, undefined, undefined ]
 ]); }