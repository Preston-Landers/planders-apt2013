
function addChartData(data) {
data.addRows([
 [new Date(2010,7,2), 70.4, undefined, undefined, undefined ],
 [new Date(2010,7,3), 70.46, undefined, undefined, undefined ],
 [new Date(2010,7,4), 71.19, undefined, undefined, undefined ],
 [new Date(2010,7,5), 71.61, undefined, undefined, undefined ],
 [new Date(2010,7,6), 71.68, undefined, undefined, undefined ],
 [new Date(2010,7,9), 71.88, undefined, undefined, undefined ],
 [new Date(2010,7,10), 72.39, undefined, undefined, undefined ],
 [new Date(2010,7,11), 71.1, undefined, undefined, undefined ],
 [new Date(2010,7,12), 71.06, undefined, undefined, undefined ],
 [new Date(2010,7,13), 70.96, undefined, undefined, undefined ],
 [new Date(2010,7,16), 70.63, undefined, undefined, undefined ],
 [new Date(2010,7,17), 71.98, undefined, undefined, undefined ],
 [new Date(2010,7,18), 72.33, undefined, undefined, undefined ],
 [new Date(2010,7,19), 71.31, undefined, undefined, undefined ],
 [new Date(2010,7,20), 70.82, undefined, undefined, undefined ],
 [new Date(2010,7,23), 71.01, undefined, undefined, undefined ],
 [new Date(2010,7,24), 69.3, undefined, undefined, undefined ],
 [new Date(2010,7,25), 69.76, undefined, undefined, undefined ],
 [new Date(2010,7,26), 68.83, undefined, undefined, undefined ],
 [new Date(2010,7,27), 69.72, undefined, undefined, undefined ],
 [new Date(2010,7,30), 69.26, undefined, undefined, undefined ],
 [new Date(2010,7,31), 68.19, undefined, undefined, undefined ],
 [new Date(2010,8,1), 69.52, undefined, undefined, undefined ]
 ]); }