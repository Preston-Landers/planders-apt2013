
function addChartData(data) {
data.addRows([
 [new Date(2010,7,2), 26.33, undefined, undefined, undefined ],
 [new Date(2010,7,3), 26.16, undefined, undefined, undefined ],
 [new Date(2010,7,4), 25.73, undefined, undefined, undefined ],
 [new Date(2010,7,5), 25.37, undefined, undefined, undefined ],
 [new Date(2010,7,6), 25.55, undefined, undefined, undefined ],
 [new Date(2010,7,9), 25.61, undefined, undefined, undefined ],
 [new Date(2010,7,10), 25.07, undefined, undefined, undefined ],
 [new Date(2010,7,11), 24.86, undefined, undefined, undefined ],
 [new Date(2010,7,12), 24.49, undefined, undefined, undefined ],
 [new Date(2010,7,13), 24.4, undefined, undefined, undefined ],
 [new Date(2010,7,16), 24.5, undefined, undefined, undefined ],
 [new Date(2010,7,17), 24.71, undefined, undefined, undefined ],
 [new Date(2010,7,18), 24.82, undefined, undefined, undefined ],
 [new Date(2010,7,19), 24.44, undefined, undefined, undefined ],
 [new Date(2010,7,20), 24.23, undefined, undefined, undefined ],
 [new Date(2010,7,23), 24.28, undefined, undefined, undefined ],
 [new Date(2010,7,24), 24.04, undefined, undefined, undefined ],
 [new Date(2010,7,25), 24.1, undefined, undefined, undefined ],
 [new Date(2010,7,26), 23.82, undefined, undefined, undefined ],
 [new Date(2010,7,27), 23.93, undefined, undefined, undefined ],
 [new Date(2010,7,30), 23.64, undefined, undefined, undefined ],
 [new Date(2010,7,31), 23.47, undefined, undefined, undefined ],
 [new Date(2010,8,1), 23.9, undefined, undefined, undefined ]
 ]); }