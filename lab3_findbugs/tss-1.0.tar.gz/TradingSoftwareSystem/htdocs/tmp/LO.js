
function addChartData(data) {
data.addRows([
 [new Date(2010,7,2), 76.36, undefined, undefined, undefined ],
 [new Date(2010,7,3), 75.79, undefined, undefined, undefined ],
 [new Date(2010,7,4), 74.8, undefined, undefined, undefined ],
 [new Date(2010,7,5), 75.89, undefined, undefined, undefined ],
 [new Date(2010,7,6), 76.32, undefined, undefined, undefined ],
 [new Date(2010,7,9), 76.11, undefined, undefined, undefined ],
 [new Date(2010,7,10), 76.18, undefined, undefined, undefined ],
 [new Date(2010,7,11), 75.71, undefined, undefined, undefined ],
 [new Date(2010,7,12), 75.3, undefined, undefined, undefined ],
 [new Date(2010,7,13), 75.3, undefined, undefined, undefined ],
 [new Date(2010,7,16), 74.46, undefined, undefined, undefined ],
 [new Date(2010,7,17), 75.86, undefined, undefined, undefined ],
 [new Date(2010,7,18), 76.22, undefined, undefined, undefined ],
 [new Date(2010,7,19), 75.28, undefined, undefined, undefined ],
 [new Date(2010,7,20), 74.74, undefined, undefined, undefined ],
 [new Date(2010,7,23), 74.65, undefined, undefined, undefined ],
 [new Date(2010,7,24), 75.34, undefined, undefined, undefined ],
 [new Date(2010,7,25), 78.04, undefined, undefined, undefined ],
 [new Date(2010,7,26), 77.93, undefined, undefined, undefined ],
 [new Date(2010,7,27), 77.2, undefined, undefined, undefined ],
 [new Date(2010,7,30), 76.16, undefined, undefined, undefined ],
 [new Date(2010,7,31), 76.01, undefined, undefined, undefined ],
 [new Date(2010,8,1), 78.2, undefined, undefined, undefined ]
 ]); }