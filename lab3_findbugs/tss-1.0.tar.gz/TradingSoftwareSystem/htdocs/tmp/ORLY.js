
function addChartData(data) {
data.addRows([
 [new Date(2010,7,2), 49.08, undefined, undefined, undefined ],
 [new Date(2010,7,3), 48.16, undefined, undefined, undefined ],
 [new Date(2010,7,4), 47.75, undefined, undefined, undefined ],
 [new Date(2010,7,5), 47.85, undefined, undefined, undefined ],
 [new Date(2010,7,6), 47.14, undefined, undefined, undefined ],
 [new Date(2010,7,9), 47.27, undefined, undefined, undefined ],
 [new Date(2010,7,10), 46.83, undefined, undefined, undefined ],
 [new Date(2010,7,11), 46.27, undefined, undefined, undefined ],
 [new Date(2010,7,12), 46.97, undefined, undefined, undefined ],
 [new Date(2010,7,13), 46.84, undefined, undefined, undefined ],
 [new Date(2010,7,16), 47.13, undefined, undefined, undefined ],
 [new Date(2010,7,17), 47.8, undefined, undefined, undefined ],
 [new Date(2010,7,18), 48.08, undefined, undefined, undefined ],
 [new Date(2010,7,19), 47.47, undefined, undefined, undefined ],
 [new Date(2010,7,20), 47.82, undefined, undefined, undefined ],
 [new Date(2010,7,23), 47.1, undefined, undefined, undefined ],
 [new Date(2010,7,24), 47.17, undefined, undefined, undefined ],
 [new Date(2010,7,25), 47.33, undefined, undefined, undefined ],
 [new Date(2010,7,26), 47.21, undefined, undefined, undefined ],
 [new Date(2010,7,27), 47.61, undefined, undefined, undefined ],
 [new Date(2010,7,30), 46.93, undefined, undefined, undefined ],
 [new Date(2010,7,31), 47.27, undefined, undefined, undefined ],
 [new Date(2010,8,1), 48.87, undefined, undefined, undefined ]
 ]); }