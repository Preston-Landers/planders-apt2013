
function addChartData(data) {
data.addRows([
 [new Date(2010,7,2), 59.71, undefined, undefined, undefined ],
 [new Date(2010,7,3), 59.5, undefined, undefined, undefined ],
 [new Date(2010,7,4), 59.57, undefined, undefined, undefined ],
 [new Date(2010,7,5), 58.81, undefined, undefined, undefined ],
 [new Date(2010,7,6), 58.8, undefined, undefined, undefined ],
 [new Date(2010,7,9), 58.55, undefined, undefined, undefined ],
 [new Date(2010,7,10), 58.65, undefined, undefined, undefined ],
 [new Date(2010,7,11), 57.82, undefined, undefined, undefined ],
 [new Date(2010,7,12), 57.93, undefined, undefined, undefined ],
 [new Date(2010,7,13), 58.15, undefined, undefined, undefined ],
 [new Date(2010,7,16), 58.36, undefined, undefined, undefined ],
 [new Date(2010,7,17), 59.16, undefined, undefined, undefined ],
 [new Date(2010,7,18), 58.97, undefined, undefined, undefined ],
 [new Date(2010,7,19), 58.03, undefined, undefined, undefined ],
 [new Date(2010,7,20), 59.65, undefined, undefined, undefined ],
 [new Date(2010,7,23), 59.79, undefined, undefined, undefined ],
 [new Date(2010,7,24), 58.83, undefined, undefined, undefined ],
 [new Date(2010,7,25), 58.81, undefined, undefined, undefined ],
 [new Date(2010,7,26), 58.34, undefined, undefined, undefined ],
 [new Date(2010,7,27), 58.33, undefined, undefined, undefined ],
 [new Date(2010,7,30), 58.15, undefined, undefined, undefined ],
 [new Date(2010,7,31), 58.48, undefined, undefined, undefined ],
 [new Date(2010,8,1), 59.75, undefined, undefined, undefined ]
 ]); }