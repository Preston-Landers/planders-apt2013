
function addChartData(data) {
data.addRows([
 [new Date(2010,7,2), 15.83, undefined, undefined, undefined ],
 [new Date(2010,7,3), 15.58, undefined, undefined, undefined ],
 [new Date(2010,7,4), 15.41, undefined, undefined, undefined ],
 [new Date(2010,7,5), 15.01, undefined, undefined, undefined ],
 [new Date(2010,7,6), 14.87, undefined, undefined, undefined ],
 [new Date(2010,7,9), 14.78, undefined, undefined, undefined ],
 [new Date(2010,7,10), 14.73, undefined, undefined, undefined ],
 [new Date(2010,7,11), 14.21, undefined, undefined, undefined ],
 [new Date(2010,7,12), 14.23, undefined, undefined, undefined ],
 [new Date(2010,7,13), 14.13, undefined, undefined, undefined ],
 [new Date(2010,7,16), 14.06, undefined, undefined, undefined ],
 [new Date(2010,7,17), 14.01, undefined, undefined, undefined ],
 [new Date(2010,7,18), 13.93, undefined, undefined, undefined ],
 [new Date(2010,7,19), 13.72, undefined, undefined, undefined ],
 [new Date(2010,7,20), 13.47, undefined, undefined, undefined ],
 [new Date(2010,7,23), 13.66, undefined, undefined, undefined ],
 [new Date(2010,7,24), 13.36, undefined, undefined, undefined ],
 [new Date(2010,7,25), 13.4, undefined, undefined, undefined ],
 [new Date(2010,7,26), 13.47, undefined, undefined, undefined ],
 [new Date(2010,7,27), 13.59, undefined, undefined, undefined ],
 [new Date(2010,7,30), 13.37, undefined, undefined, undefined ],
 [new Date(2010,7,31), 12.83, undefined, undefined, undefined ],
 [new Date(2010,8,1), 12.94, undefined, undefined, undefined ]
 ]); }