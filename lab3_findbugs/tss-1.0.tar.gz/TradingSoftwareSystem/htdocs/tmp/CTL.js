
function addChartData(data) {
data.addRows([
 [new Date(2010,7,2), 35.98, undefined, undefined, undefined ],
 [new Date(2010,7,3), 35.87, undefined, undefined, undefined ],
 [new Date(2010,7,4), 36.33, undefined, undefined, undefined ],
 [new Date(2010,7,5), 36.26, undefined, undefined, undefined ],
 [new Date(2010,7,6), 36.39, undefined, undefined, undefined ],
 [new Date(2010,7,9), 36.35, undefined, undefined, undefined ],
 [new Date(2010,7,10), 36.49, undefined, undefined, undefined ],
 [new Date(2010,7,11), 36.24, undefined, undefined, undefined ],
 [new Date(2010,7,12), 35.92, undefined, undefined, undefined ],
 [new Date(2010,7,13), 36.05, undefined, undefined, undefined ],
 [new Date(2010,7,16), 36.26, undefined, undefined, undefined ],
 [new Date(2010,7,17), 36.19, undefined, undefined, undefined ],
 [new Date(2010,7,18), 36.23, undefined, undefined, undefined ],
 [new Date(2010,7,19), 36.05, undefined, undefined, undefined ],
 [new Date(2010,7,20), 35.99, undefined, undefined, undefined ],
 [new Date(2010,7,23), 35.91, undefined, undefined, undefined ],
 [new Date(2010,7,24), 36.01, undefined, undefined, undefined ],
 [new Date(2010,7,25), 35.97, undefined, undefined, undefined ],
 [new Date(2010,7,26), 36.0, undefined, undefined, undefined ],
 [new Date(2010,7,27), 36.12, undefined, undefined, undefined ],
 [new Date(2010,7,30), 35.98, undefined, undefined, undefined ],
 [new Date(2010,7,31), 36.16, undefined, undefined, undefined ],
 [new Date(2010,8,1), 36.73, undefined, undefined, undefined ]
 ]); }