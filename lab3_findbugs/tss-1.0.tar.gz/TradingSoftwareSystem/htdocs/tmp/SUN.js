
function addChartData(data) {
data.addRows([
 [new Date(2010,7,2), 35.78, undefined, undefined, undefined ],
 [new Date(2010,7,3), 36.26, undefined, undefined, undefined ],
 [new Date(2010,7,4), 37.51, undefined, undefined, undefined ],
 [new Date(2010,7,5), 37.82, undefined, undefined, undefined ],
 [new Date(2010,7,6), 37.52, undefined, undefined, undefined ],
 [new Date(2010,7,9), 37.82, undefined, undefined, undefined ],
 [new Date(2010,7,10), 37.65, undefined, undefined, undefined ],
 [new Date(2010,7,11), 35.53, undefined, undefined, undefined ],
 [new Date(2010,7,12), 35.1, undefined, undefined, undefined ],
 [new Date(2010,7,13), 35.7, undefined, undefined, undefined ],
 [new Date(2010,7,16), 35.59, undefined, undefined, undefined ],
 [new Date(2010,7,17), 35.76, undefined, undefined, undefined ],
 [new Date(2010,7,18), 35.72, undefined, undefined, undefined ],
 [new Date(2010,7,19), 35.63, undefined, undefined, undefined ],
 [new Date(2010,7,20), 35.01, undefined, undefined, undefined ],
 [new Date(2010,7,23), 34.85, undefined, undefined, undefined ],
 [new Date(2010,7,24), 34.02, undefined, undefined, undefined ],
 [new Date(2010,7,25), 33.96, undefined, undefined, undefined ],
 [new Date(2010,7,26), 33.75, undefined, undefined, undefined ],
 [new Date(2010,7,27), 34.4, undefined, undefined, undefined ],
 [new Date(2010,7,30), 34.01, undefined, undefined, undefined ],
 [new Date(2010,7,31), 33.68, undefined, undefined, undefined ],
 [new Date(2010,8,1), 34.08, undefined, undefined, undefined ]
 ]); }