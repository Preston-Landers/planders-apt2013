
function addChartData(data) {
data.addRows([
 [new Date(2010,7,2), 87.87, undefined, undefined, undefined ],
 [new Date(2010,7,3), 87.8, undefined, undefined, undefined ],
 [new Date(2010,7,4), 88.45, undefined, undefined, undefined ],
 [new Date(2010,7,5), 88.56, undefined, undefined, undefined ],
 [new Date(2010,7,6), 87.76, undefined, undefined, undefined ],
 [new Date(2010,7,9), 88.78, undefined, undefined, undefined ],
 [new Date(2010,7,10), 88.69, undefined, undefined, undefined ],
 [new Date(2010,7,11), 86.86, undefined, undefined, undefined ],
 [new Date(2010,7,12), 87.31, undefined, undefined, undefined ],
 [new Date(2010,7,13), 87.29, undefined, undefined, undefined ],
 [new Date(2010,7,16), 87.98, undefined, undefined, undefined ],
 [new Date(2010,7,17), 89.14, undefined, undefined, undefined ],
 [new Date(2010,7,18), 89.09, undefined, undefined, undefined ],
 [new Date(2010,7,19), 88.11, undefined, undefined, undefined ],
 [new Date(2010,7,20), 88.35, undefined, undefined, undefined ],
 [new Date(2010,7,23), 87.49, undefined, undefined, undefined ],
 [new Date(2010,7,24), 86.18, undefined, undefined, undefined ],
 [new Date(2010,7,25), 85.93, undefined, undefined, undefined ],
 [new Date(2010,7,26), 85.58, undefined, undefined, undefined ],
 [new Date(2010,7,27), 87.28, undefined, undefined, undefined ],
 [new Date(2010,7,30), 85.94, undefined, undefined, undefined ],
 [new Date(2010,7,31), 86.03, undefined, undefined, undefined ],
 [new Date(2010,8,1), 87.1, undefined, undefined, undefined ]
 ]); }