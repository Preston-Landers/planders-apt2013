
function addChartData(data) {
data.addRows([
 [new Date(2010,7,2), 79.56, undefined, undefined, undefined ],
 [new Date(2010,7,3), 79.18, undefined, undefined, undefined ],
 [new Date(2010,7,4), 78.94, undefined, undefined, undefined ],
 [new Date(2010,7,5), 79.48, undefined, undefined, undefined ],
 [new Date(2010,7,6), 79.75, undefined, undefined, undefined ],
 [new Date(2010,7,9), 79.65, undefined, undefined, undefined ],
 [new Date(2010,7,10), 79.55, undefined, undefined, undefined ],
 [new Date(2010,7,11), 78.58, undefined, undefined, undefined ],
 [new Date(2010,7,12), 77.92, undefined, undefined, undefined ],
 [new Date(2010,7,13), 78.11, undefined, undefined, undefined ],
 [new Date(2010,7,16), 78.16, undefined, undefined, undefined ],
 [new Date(2010,7,17), 79.23, undefined, undefined, undefined ],
 [new Date(2010,7,18), 79.38, undefined, undefined, undefined ],
 [new Date(2010,7,19), 77.86, undefined, undefined, undefined ],
 [new Date(2010,7,20), 77.46, undefined, undefined, undefined ],
 [new Date(2010,7,23), 78.39, undefined, undefined, undefined ],
 [new Date(2010,7,24), 78.17, undefined, undefined, undefined ],
 [new Date(2010,7,25), 78.31, undefined, undefined, undefined ],
 [new Date(2010,7,26), 77.5, undefined, undefined, undefined ],
 [new Date(2010,7,27), 79.64, undefined, undefined, undefined ],
 [new Date(2010,7,30), 78.35, undefined, undefined, undefined ],
 [new Date(2010,7,31), 78.84, undefined, undefined, undefined ],
 [new Date(2010,8,1), 80.33, undefined, undefined, undefined ]
 ]); }