
function addChartData(data) {
data.addRows([
 [new Date(2010,7,2), 77.8, undefined, undefined, undefined ],
 [new Date(2010,7,3), 78.66, undefined, undefined, undefined ],
 [new Date(2010,7,4), 79.02, undefined, undefined, undefined ],
 [new Date(2010,7,5), 79.07, undefined, undefined, undefined ],
 [new Date(2010,7,6), 78.73, undefined, undefined, undefined ],
 [new Date(2010,7,9), 79.29, undefined, undefined, undefined ],
 [new Date(2010,7,10), 79.04, undefined, undefined, undefined ],
 [new Date(2010,7,11), 77.13, undefined, undefined, undefined ],
 [new Date(2010,7,12), 77.07, undefined, undefined, undefined ],
 [new Date(2010,7,13), 77.4, undefined, undefined, undefined ],
 [new Date(2010,7,16), 77.71, undefined, undefined, undefined ],
 [new Date(2010,7,17), 77.77, undefined, undefined, undefined ],
 [new Date(2010,7,18), 77.04, undefined, undefined, undefined ],
 [new Date(2010,7,19), 75.84, undefined, undefined, undefined ],
 [new Date(2010,7,20), 75.05, undefined, undefined, undefined ],
 [new Date(2010,7,23), 75.05, undefined, undefined, undefined ],
 [new Date(2010,7,24), 73.78, undefined, undefined, undefined ],
 [new Date(2010,7,25), 74.07, undefined, undefined, undefined ],
 [new Date(2010,7,26), 73.33, undefined, undefined, undefined ],
 [new Date(2010,7,27), 74.93, undefined, undefined, undefined ],
 [new Date(2010,7,30), 73.78, undefined, undefined, undefined ],
 [new Date(2010,7,31), 74.08, undefined, undefined, undefined ],
 [new Date(2010,8,1), 76.77, undefined, undefined, undefined ]
 ]); }