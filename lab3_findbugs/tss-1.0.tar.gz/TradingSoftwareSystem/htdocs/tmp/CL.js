
function addChartData(data) {
data.addRows([
 [new Date(2010,7,2), 78.25, undefined, undefined, undefined ],
 [new Date(2010,7,3), 78.14, undefined, undefined, undefined ],
 [new Date(2010,7,4), 78.06, undefined, undefined, undefined ],
 [new Date(2010,7,5), 77.13, undefined, undefined, undefined ],
 [new Date(2010,7,6), 76.5, undefined, undefined, undefined ],
 [new Date(2010,7,9), 76.27, undefined, undefined, undefined ],
 [new Date(2010,7,10), 77.97, undefined, undefined, undefined ],
 [new Date(2010,7,11), 76.47, undefined, undefined, undefined ],
 [new Date(2010,7,12), 77.02, undefined, undefined, undefined ],
 [new Date(2010,7,13), 76.39, undefined, undefined, undefined ],
 [new Date(2010,7,16), 76.17, undefined, undefined, undefined ],
 [new Date(2010,7,17), 76.45, undefined, undefined, undefined ],
 [new Date(2010,7,18), 76.8, undefined, undefined, undefined ],
 [new Date(2010,7,19), 76.75, undefined, undefined, undefined ],
 [new Date(2010,7,20), 76.03, undefined, undefined, undefined ],
 [new Date(2010,7,23), 75.52, undefined, undefined, undefined ],
 [new Date(2010,7,24), 75.47, undefined, undefined, undefined ],
 [new Date(2010,7,25), 75.28, undefined, undefined, undefined ],
 [new Date(2010,7,26), 73.99, undefined, undefined, undefined ],
 [new Date(2010,7,27), 74.25, undefined, undefined, undefined ],
 [new Date(2010,7,30), 73.86, undefined, undefined, undefined ],
 [new Date(2010,7,31), 73.84, undefined, undefined, undefined ],
 [new Date(2010,8,1), 74.92, undefined, undefined, undefined ]
 ]); }