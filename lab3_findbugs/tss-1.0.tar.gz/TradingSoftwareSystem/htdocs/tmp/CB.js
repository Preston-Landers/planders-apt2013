
function addChartData(data) {
data.addRows([
 [new Date(2010,7,2), 53.2, undefined, undefined, undefined ],
 [new Date(2010,7,3), 52.93, undefined, undefined, undefined ],
 [new Date(2010,7,4), 53.59, undefined, undefined, undefined ],
 [new Date(2010,7,5), 53.58, undefined, undefined, undefined ],
 [new Date(2010,7,6), 53.76, undefined, undefined, undefined ],
 [new Date(2010,7,9), 54.29, undefined, undefined, undefined ],
 [new Date(2010,7,10), 54.03, undefined, undefined, undefined ],
 [new Date(2010,7,11), 52.85, undefined, undefined, undefined ],
 [new Date(2010,7,12), 53.11, undefined, undefined, undefined ],
 [new Date(2010,7,13), 53.1, undefined, undefined, undefined ],
 [new Date(2010,7,16), 53.15, undefined, undefined, undefined ],
 [new Date(2010,7,17), 53.62, undefined, undefined, undefined ],
 [new Date(2010,7,18), 53.65, undefined, undefined, undefined ],
 [new Date(2010,7,19), 53.03, undefined, undefined, undefined ],
 [new Date(2010,7,20), 53.39, undefined, undefined, undefined ],
 [new Date(2010,7,23), 53.27, undefined, undefined, undefined ],
 [new Date(2010,7,24), 53.61, undefined, undefined, undefined ],
 [new Date(2010,7,25), 53.83, undefined, undefined, undefined ],
 [new Date(2010,7,26), 53.44, undefined, undefined, undefined ],
 [new Date(2010,7,27), 54.48, undefined, undefined, undefined ],
 [new Date(2010,7,30), 54.4, undefined, undefined, undefined ],
 [new Date(2010,7,31), 55.13, undefined, undefined, undefined ],
 [new Date(2010,8,1), 55.85, undefined, undefined, undefined ]
 ]); }