
function addChartData(data) {
data.addRows([
 [new Date(2010,7,2), 23.52, undefined, undefined, undefined ],
 [new Date(2010,7,3), 23.42, undefined, undefined, undefined ],
 [new Date(2010,7,4), 23.55, undefined, undefined, undefined ],
 [new Date(2010,7,5), 23.47, undefined, undefined, undefined ],
 [new Date(2010,7,6), 23.35, undefined, undefined, undefined ],
 [new Date(2010,7,9), 23.47, undefined, undefined, undefined ],
 [new Date(2010,7,10), 23.52, undefined, undefined, undefined ],
 [new Date(2010,7,11), 23.93, undefined, undefined, undefined ],
 [new Date(2010,7,12), 24.01, undefined, undefined, undefined ],
 [new Date(2010,7,13), 24.11, undefined, undefined, undefined ],
 [new Date(2010,7,16), 23.96, undefined, undefined, undefined ],
 [new Date(2010,7,17), 23.88, undefined, undefined, undefined ],
 [new Date(2010,7,18), 23.91, undefined, undefined, undefined ],
 [new Date(2010,7,19), 23.96, undefined, undefined, undefined ],
 [new Date(2010,7,20), 24.13, undefined, undefined, undefined ],
 [new Date(2010,7,23), 24.18, undefined, undefined, undefined ],
 [new Date(2010,7,24), 24.14, undefined, undefined, undefined ],
 [new Date(2010,7,25), 24.18, undefined, undefined, undefined ],
 [new Date(2010,7,26), 24.03, undefined, undefined, undefined ],
 [new Date(2010,7,27), 24.07, undefined, undefined, undefined ],
 [new Date(2010,7,30), 24.14, undefined, undefined, undefined ],
 [new Date(2010,7,31), 24.12, undefined, undefined, undefined ],
 [new Date(2010,8,1), 23.93, undefined, undefined, undefined ]
 ]); }