
function addChartData(data) {
data.addRows([
 [new Date(2010,7,2), 41.49, undefined, undefined, undefined ],
 [new Date(2010,7,3), 41.15, undefined, undefined, undefined ],
 [new Date(2010,7,4), 41.51, undefined, undefined, undefined ],
 [new Date(2010,7,5), 41.45, undefined, undefined, undefined ],
 [new Date(2010,7,6), 41.26, undefined, undefined, undefined ],
 [new Date(2010,7,9), 41.55, undefined, undefined, undefined ],
 [new Date(2010,7,10), 41.22, undefined, undefined, undefined ],
 [new Date(2010,7,11), 39.93, undefined, undefined, undefined ],
 [new Date(2010,7,12), 39.69, undefined, undefined, undefined ],
 [new Date(2010,7,13), 39.55, undefined, undefined, undefined ],
 [new Date(2010,7,16), 39.52, undefined, undefined, undefined ],
 [new Date(2010,7,17), 40.17, undefined, undefined, undefined ],
 [new Date(2010,7,18), 40.25, undefined, undefined, undefined ],
 [new Date(2010,7,19), 39.55, undefined, undefined, undefined ],
 [new Date(2010,7,20), 39.47, undefined, undefined, undefined ],
 [new Date(2010,7,23), 39.27, undefined, undefined, undefined ],
 [new Date(2010,7,24), 38.69, undefined, undefined, undefined ],
 [new Date(2010,7,25), 38.84, undefined, undefined, undefined ],
 [new Date(2010,7,26), 38.59, undefined, undefined, undefined ],
 [new Date(2010,7,27), 39.29, undefined, undefined, undefined ],
 [new Date(2010,7,30), 38.66, undefined, undefined, undefined ],
 [new Date(2010,7,31), 38.65, undefined, undefined, undefined ],
 [new Date(2010,8,1), 39.86, undefined, undefined, undefined ]
 ]); }