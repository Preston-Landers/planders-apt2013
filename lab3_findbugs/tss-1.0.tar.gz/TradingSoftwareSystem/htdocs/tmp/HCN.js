
function addChartData(data) {
data.addRows([
 [new Date(2010,7,2), 46.56, undefined, undefined, undefined ],
 [new Date(2010,7,3), 46.03, undefined, undefined, undefined ],
 [new Date(2010,7,4), 46.01, undefined, undefined, undefined ],
 [new Date(2010,7,5), 45.5, undefined, undefined, undefined ],
 [new Date(2010,7,6), 45.49, undefined, undefined, undefined ],
 [new Date(2010,7,9), 45.6, undefined, undefined, undefined ],
 [new Date(2010,7,10), 45.58, undefined, undefined, undefined ],
 [new Date(2010,7,11), 44.71, undefined, undefined, undefined ],
 [new Date(2010,7,12), 44.66, undefined, undefined, undefined ],
 [new Date(2010,7,13), 44.72, undefined, undefined, undefined ],
 [new Date(2010,7,16), 44.49, undefined, undefined, undefined ],
 [new Date(2010,7,17), 45.39, undefined, undefined, undefined ],
 [new Date(2010,7,18), 45.35, undefined, undefined, undefined ],
 [new Date(2010,7,19), 44.86, undefined, undefined, undefined ],
 [new Date(2010,7,20), 45.08, undefined, undefined, undefined ],
 [new Date(2010,7,23), 44.67, undefined, undefined, undefined ],
 [new Date(2010,7,24), 44.82, undefined, undefined, undefined ],
 [new Date(2010,7,25), 45.23, undefined, undefined, undefined ],
 [new Date(2010,7,26), 44.87, undefined, undefined, undefined ],
 [new Date(2010,7,27), 45.69, undefined, undefined, undefined ],
 [new Date(2010,7,30), 45.44, undefined, undefined, undefined ],
 [new Date(2010,7,31), 45.93, undefined, undefined, undefined ],
 [new Date(2010,8,1), 46.83, undefined, undefined, undefined ]
 ]); }