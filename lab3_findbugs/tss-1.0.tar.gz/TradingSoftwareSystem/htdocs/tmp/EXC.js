
function addChartData(data) {
data.addRows([
 [new Date(2010,7,2), 42.43, undefined, undefined, undefined ],
 [new Date(2010,7,3), 42.42, undefined, undefined, undefined ],
 [new Date(2010,7,4), 42.45, undefined, undefined, undefined ],
 [new Date(2010,7,5), 42.16, undefined, undefined, undefined ],
 [new Date(2010,7,6), 42.17, undefined, undefined, undefined ],
 [new Date(2010,7,9), 42.37, undefined, undefined, undefined ],
 [new Date(2010,7,10), 42.6, undefined, undefined, undefined ],
 [new Date(2010,7,11), 41.99, undefined, undefined, undefined ],
 [new Date(2010,7,12), 41.25, undefined, undefined, undefined ],
 [new Date(2010,7,13), 41.37, undefined, undefined, undefined ],
 [new Date(2010,7,16), 41.21, undefined, undefined, undefined ],
 [new Date(2010,7,17), 41.36, undefined, undefined, undefined ],
 [new Date(2010,7,18), 41.15, undefined, undefined, undefined ],
 [new Date(2010,7,19), 40.56, undefined, undefined, undefined ],
 [new Date(2010,7,20), 40.41, undefined, undefined, undefined ],
 [new Date(2010,7,23), 40.55, undefined, undefined, undefined ],
 [new Date(2010,7,24), 40.05, undefined, undefined, undefined ],
 [new Date(2010,7,25), 40.03, undefined, undefined, undefined ],
 [new Date(2010,7,26), 40.08, undefined, undefined, undefined ],
 [new Date(2010,7,27), 40.76, undefined, undefined, undefined ],
 [new Date(2010,7,30), 40.52, undefined, undefined, undefined ],
 [new Date(2010,7,31), 40.72, undefined, undefined, undefined ],
 [new Date(2010,8,1), 41.66, undefined, undefined, undefined ]
 ]); }